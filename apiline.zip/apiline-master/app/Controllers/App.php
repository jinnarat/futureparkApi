<?php

namespace App;

require_once 'third_party/phpqrcode/qrconst.php';
require_once 'third_party/phpqrcode/qrconfig.php';
require_once 'third_party/phpqrcode/qrtools.php';
require_once 'third_party/phpqrcode/qrspec.php';
require_once 'third_party/phpqrcode/qrimage.php';
require_once 'third_party/phpqrcode/qrinput.php';
require_once 'third_party/phpqrcode/qrbitstream.php';
require_once 'third_party/phpqrcode/qrsplit.php';
require_once 'third_party/phpqrcode/qrrscode.php';
require_once 'third_party/phpqrcode/qrmask.php';
require_once 'third_party/phpqrcode/qrencode.php';

use \Psr\Container\ContainerInterface;
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;

class App
{   
    protected $db_api_tracking;
    protected $db_cdpmkt;
    protected $otp_template;
    protected $sms;
    protected $smtp;
    protected $path;
    protected $url;

    public function __construct(ContainerInterface $container)
    {
        $this->db_api_tracking = $container->get('db_api_tracking');
        $this->db_cdpmkt = $container->get('db_cdpmkt');
        $this->otp_template = $container->get('otp_template');
        $this->sms = $container->get('sms');
        $this->smtp = $container->get('smtp');
        $this->path = $container->get('path');
        $this->url = $container->get('url');
    }

    public function getIpAddress()
    {
        if(!empty($_SERVER['HTTP_CLIENT_IP']))
        {
            $ip = $_SERVER['HTTP_CLIENT_IP'];
        }
        else if(!empty($_SERVER['HTTP_X_FORWARDED_FOR']))
        {
            $ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
        }
        else
        {
            $ip = $_SERVER['REMOTE_ADDR'];
        }

        return $ip;
    }

    public function validToken($access_token, $datetime_now)
    {
        $__response_data = array();

        $stmt = $this->db_api_tracking->prepare('EXEC _Token @type = ?, @access_token = ?, @status = ?');

        $stmt->bindValue(1, 'Select');
        $stmt->bindValue(2, $access_token);
        $stmt->bindValue(3, 'Active');

        $stmt->execute();

        $__token = $stmt->fetch();

        if(isset($__token['tok_access_token']))
        {
            $expire_in = date('Y-m-d H:i:s', strtotime($__token['tok_createdatetime']. ' +' . $__token['tok_expirein'] . ' sec'));

            if($expire_in >= $datetime_now)
            {
                $__response_data = array(
                    'data' => array(),
                    'status' => 200
                ); 
            }
            else
            {
                $__response_data = array(
                    'data' => array
                    (
                        'error' => array(
                            'errorType' => 'expired_token',
                            'message' => 'Access token expired.'
                        ),                    
                        'success' => false
                    ),
                    'status' => 401
                ); 
            }
        }
        else
        {
            $__response_data = array(
                'data' => array
                (
                    'error' => array(
                        'errorType' => 'invalid_token',
                        'message' => 'Access token invalid.'
                    ),                    
                    'success' => false
                ),
                'status' => 401
            );
        }

        return $__response_data;
    }

    public function generateToken($key)
    {
        $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
        $charactersLength = strlen($characters);
        $randomString = '';

        for ($i = 0; $i < 25; $i++)
        {
            $randomString .= $characters[rand(0, $charactersLength - 1)];
        }

        return hash_hmac('sha256', $randomString, $key);
    }

    function generateRandomString($length, $type = null)
    {
        if($type == 'number')
        {
			$characters = '0123456789';
        }
        else
        {
			$characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
        }
        
		$charactersLength = strlen($characters);
        $randomString = '';
        
        for ($i = 0; $i < $length; $i++)
        {
			$randomString .= $characters[rand(0, $charactersLength - 1)];
        }
        
		return $randomString;
    }
    
    function validateDate($date, $format = 'Y-m-d')
    {
        $d = \DateTime::createFromFormat($format, $date);
        
        return $d && $d->format($format) === $date;
    }

    public function sendSMS($mobile, $sms_text)
    {
        $mysmsmessage = urlencode($sms_text);
        
		$smshost = $this->sms['host'];
		$smsuser = $this->sms['user'];
		$smspassword = $this->sms['pass'];
		$sendername = $this->sms['sender_name'];
		
		$myurl = $smshost.'/api/sendsms/plain?user='.$smsuser.'&password='.$smspassword.'&sender='.$sendername.'&SMSText='.$mysmsmessage.'&GSM='.$mobile.'&type=LongSMS&datacoding=8&encoding=UTF-8';
	   	
		$curl = curl_init();
		
		curl_setopt_array($curl, array(
			CURLOPT_RETURNTRANSFER => 1,
			CURLOPT_URL => $myurl,
			CURLOPT_USERAGENT => 'SMS Alert Service'
        ));

        $response = curl_exec($curl);
        	
        curl_close($curl);

        $status = 0;
        $message = '';

        switch($response)
        {
			case '-1' :
				$status = -1;
				$message = 'Error in processing the request';
			    break;
            case '-2' :
                $status = -2;
				$message = 'Not enough credits on a specific account';
			    break;
            case '-3' :
                $status = -3;
				$message = 'Targeted network is not covered on specific account';
			    break;
            case '-5' :
                $status = -5;
				$message = 'Username or password is invalid';
			    break;
            case '-6' :
                $status = -6;
				$message = 'Destination address is missing in the request';
			    break;
            case '-10' :
                $status = -10;
				$message = 'Username is missing in the request';
			    break;
            case '-11' :
                $status = -11;
				$message = 'Password is missing in the request';
			    break;
            case '-13' :
                $status = -13;
				$message = 'Number is not recognized by Infobip platform';
			    break;
            case '-22' :
                $status = -22;
				$message = 'Incorrect XML format, caused by syntax error';
			    break;
            case '-23' :
                $status = -23;
				$message = 'General error, reasons may vary';
			    break;
            case '-26' :
                $status = -26;
				$message = 'General API error, reasons may vary';
			    break;
            case '-27' :
                $status = -27;
				$message = 'Invalid scheduling parametar';
			    break;
            case '-28' :
                $status = -28;
				$message = 'Invalid PushURL in the request';
			    break;
            case '-30' :
                $status = -30;
				$message = 'Invalid APPID in the request';
			    break;
            case '-33' :
                $status = -33;
				$message = 'Duplicated MessageID in the request';
			    break;
            case '-34' :
                $status = -34;
				$message = 'Sender name is not allowed';
			    break;
            case '-99' :
                $status = -99;
				$message = 'Error in processing request, reasons may vary';
			    break;
            case ' ' :
                $status = ' ';
				$message = 'Bad Request';
			    break;
            default :
                $status = 0;
				$message = 'Request was successful (all recipients)';
			    break;
        }
        
		return array(
            'response' => $response,
            'status' => $status,
            'description' => $message
        );
    }
    
    public function sendEmail($mailto, $subject, $body)
    {
        $response = array();

        $mail = new PHPMailer(true);

        try
        {
            $mail->isSMTP();
            // $mail->SMTPDebug = 3;
            $mail->Host = $this->smtp['host'];
            $mail->SMTPAuth = true;
            $mail->Username = $this->smtp['user'];
            $mail->Password = $this->smtp['pass'];
            $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
            $mail->Port = $this->smtp['port'];
            $mail->CharSet = 'UTF-8';
            
            $mail->setFrom($this->smtp['user'], $this->smtp['sender_name']);
            $mail->addAddress($mailto);
            
            $mail->isHTML(true);
            $mail->Subject = $subject;
            $mail->Body = $body;
        
            if(!$mail->Send())
            {
                $response['response'] = 500;
                $response['description'] = $mail->ErrorInfo;
            }
            else
            {
                $response['response'] = 200;
                $response['description'] = 'OK';
            }
        }
        catch (Exception $ex)
        {
            $response['response'] = 500;
            $response['description'] = $ex->getMessage();
        }

        return $response;
    }

    public function isNullOrEmpty($field, $form_data)
    {
        $response = array(
            'status' => 200,
            'detail' => array(
                'success' => true
            )
        );

        foreach($field as $f)
        {
            if(!isset($form_data[$f]))
            {
                $response = array(
                    'status' => 400,
                    'detail' => array(
                        'error' => array(
                            'errorType' => 'invalid_request',
                            'fieldName' => $f,
                            'message' => 'Missing parameters: ' . $f
                        ),
                        'success' => false
                    )
                );

                break;
            }
            else
            {
                if($form_data[$f] == '')
                {
                    $response = array(
                        'status' => 400,
                        'detail' => array(
                            'error' => array(
                                'errorType' => 'invalid_request',
                                'fieldName' => $f,
                                'message' => 'Missing ' . $f . ' parameter value.'
                            ),
                            'success' => false
                        )
                    );

                    break;
                }
            }
        }

        return $response;
    }

    public function isNull($field, $form_data)
    {
        $response = array(
            'status' => 200,
            'detail' => array(
                'success' => true
            )
        );

        foreach($field as $f)
        {
            if(isset($form_data[$f]) && $form_data[$f] == '')
            {
                $response = array(
                    'status' => 400,
                    'detail' => array(
                        'error' => array(
                            'errorType' => 'invalid_request',
                            'fieldName' => $f,
                            'message' => 'Missing ' . $f . ' parameter value.'
                        ),
                        'success' => false
                    )
                );

                break;
            }
        }

        return $response;
    }

    public function genereate_qr_code($text, $physical_path, $save_path, $file_name)
	{
		if(is_dir($physical_path . $save_path) === false)
		{
			mkdir($physical_path . $save_path, 0777, true);
		}

		\QRcode::png($text, $physical_path . $save_path . $file_name, $margin = 2);

		return $save_path . $file_name;
	}

    public function bindValue($stmt, $ar)
    {
        $i = 1;

        foreach($ar as $a => $b)
        {
            $stmt->bindValue($i, $b);

            $i++;
        }
        
        return $stmt;
    }
}