<?php

namespace App;

use \Psr\Container\ContainerInterface;
use \Psr\Http\Message\ServerRequestInterface as Request;
use \Psr\Http\Message\ResponseInterface as Response;

class Oauth2 extends App
{
    public function __construct(ContainerInterface $container)
    {
        parent::__construct($container);
    }

    public function token(Request $req, Response $res, array $args)
    {
        $__response_status_code = 200;
        $__response_data = array();

        $db_api_tracking = $this->db_api_tracking;

        try
        {
            $db_api_tracking->beginTransaction();

            $datetime_now = date('Y-m-d H:i:s');

            $_clien_id = '';
            $_client_secret = '';

            $req_body = $req->getParsedBody();

            if(isset($req_body['grant_type']))
            {
                if($req_body['grant_type'] == 'token')
                {
                    if($req->getHeader('Authorization'))
                    {
                        $req_authorization = $req->getHeader('Authorization')[0];
                        $code = explode(':', base64_decode(explode(' ', $req_authorization)[1]));
            
                        $_clien_id = isset($code[0]) ? $code[0] : '';
                        $_client_secret = isset($code[1]) ? $code[1] : '';
                    }
                    else
                    {
                        $__response_status_code = 401;
                        $__response_data = array(
                            'error' => array(
                                'errorType' => 'invalid_client',
                                'message' => 'Authorization header required.'
                            ),
                            'success' => false
                        );
                    }

                    if($__response_status_code == 200)
                    {
                        $stmt = $db_api_tracking->prepare('EXEC _Applications @type = ?, @client_id = ?, @client_secret = ?, @status = ?');

                        $stmt->bindValue(1, 'Select');
                        $stmt->bindValue(2, $_clien_id);
                        $stmt->bindValue(3, $_client_secret);
                        $stmt->bindValue(4, 'Active');

                        $stmt->execute();

                        $__application = $stmt->fetch();

                        if(isset($__application['app_id']) && $__application['app_id'] != '')
                        {
                            $access_token = '';
                            $refresh_token = '';

                            do
                            {
                                $access_token = $this->generateToken($__application['app_id']);
                                $refresh_token = $this->generateToken($__application['app_id']);

                                $stmt = $db_api_tracking->prepare('EXEC _Token @type = ?, @access_token = ?, @refresh_token = ?');

                                $stmt->bindValue(1, 'Select');
                                $stmt->bindValue(2, $access_token);
                                $stmt->bindValue(3, $refresh_token);

                                $stmt->execute();
                            }
                            while(count($stmt->fetchAll()) > 0);

                            $stmt = $db_api_tracking->prepare('EXEC _Token @type = ?, @application_id = ?, @access_token = ?, @refresh_token = ?, @expire_in = ?, @status = ?, @createdatetime = ?, @createby = ?, @updatedatetime = ?, @updateby = ?');

                            $stmt->bindValue(1, 'Insert');
                            $stmt->bindValue(2, $__application['app_id']);
                            $stmt->bindValue(3, $access_token);
                            $stmt->bindValue(4, $refresh_token);
                            $stmt->bindValue(5, 28800);
                            $stmt->bindValue(6, 'Active');
                            $stmt->bindValue(7, $datetime_now);
                            $stmt->bindValue(8, 2);
                            $stmt->bindValue(9, $datetime_now);
                            $stmt->bindValue(10, 2);

                            $stmt->execute();

                            $__response_status_code = 200;
                            $__response_data = array(                                
                                'access_token' => $access_token,
                                'app_id' => $__application['app_id'],
                                'expires_in' => 28800,
                                'refresh_token' => $refresh_token,
                                'token_type' => 'Bearer'
                            );
                        }
                        else
                        {
                            $__response_status_code = 401;
                            $__response_data = array(
                                'error' => array(
                                    'errorType' => 'invalid_client',
                                    'message' => 'Client id or Client secret invalid.'
                                ),
                                'success' => false
                            );
                        }
                    }
                }
                else if($req_body['grant_type'] == 'refresh')
                {
                    if($req->getHeader('Authorization'))
                    {
                        $req_authorization = $req->getHeader('Authorization')[0];
                        $code = explode(':', base64_decode(explode(' ', $req_authorization)[1]));
            
                        $_clien_id = isset($code[0]) ? $code[0] : '';
                        $_client_secret = isset($code[1]) ? $code[1] : '';
                    }
                    else
                    {
                        $__response_status_code = 401;
                        $__response_data = array(
                            'error' => array(
                                'errorType' => 'invalid_client',
                                'message' => 'Authorization header required.'
                            ),
                            'success' => false
                        );
                    }

                    if(!isset($req_body['refresh_token']))
                    {
                        $__response_status_code = 400;
                        $__response_data = array(
                            'error' => array(
                                'errorType' => 'invalid_request',
                                'fieldName' => 'refresh_token',
                                'message' => 'Missing parameters: refresh_token'
                            ),
                            'success' => false
                        );
                    }
                    else if($req_body['refresh_token'] == '')
                    {
                        $__response_status_code = 400;
                        $__response_data = array(
                            'error' => array(
                                'errorType' => 'invalid_request',
                                'fieldName' => 'refresh_token',
                                'message' => 'Missing refresh_token parameter value.'
                            ),
                            'success' => false
                        );
                    }

                    if($__response_status_code == 200)
                    {
                        $stmt = $db_api_tracking->prepare('EXEC _Applications @type = ?, @client_id = ?, @client_secret = ?, @status = ?');

                        $stmt->bindValue(1, 'Select');
                        $stmt->bindValue(2, $_clien_id);
                        $stmt->bindValue(3, $_client_secret);
                        $stmt->bindValue(4, 'Active');

                        $stmt->execute();

                        $__application = $stmt->fetch();

                        if(isset($__application['app_id']) && $__application['app_id'] != '')
                        {
                            $access_token = '';
                            $refresh_token = $req_body['refresh_token'];

                            $stmt = $db_api_tracking->prepare('EXEC _Token @type = ?, @refresh_token = ?, @status = ?');

                            $stmt->bindValue(1, 'Select');
                            $stmt->bindValue(2, $refresh_token);
                            $stmt->bindValue(3, 'Active');
    
                            $stmt->execute();

                            if(count($stmt->fetchAll()) > 0)
                            {
                                $stmt = $db_api_tracking->prepare('EXEC _Token @type = ?, @refresh_token = ?, @status = ?, @updatedatetime = ?, @updateby = ?');

                                $stmt->bindValue(1, 'Update');
                                $stmt->bindValue(2, $refresh_token);
                                $stmt->bindValue(3, 'Refresh');
                                $stmt->bindValue(4, $datetime_now);
                                $stmt->bindValue(5, 1);
        
                                $stmt->execute();

                                do
                                {
                                    $access_token = $this->generateToken($__application['app_id']);
                                    $refresh_token = $this->generateToken($__application['app_id']);

                                    $stmt = $db_api_tracking->prepare('EXEC _Token @type = ?,  @access_token = ?, @refresh_token = ?');

                                    $stmt->bindValue(1, 'Select');
                                    $stmt->bindValue(2, $access_token);
                                    $stmt->bindValue(3, $refresh_token);

                                    $stmt->execute();
                                }
                                while(count($stmt->fetchAll()) > 0);

                                $stmt = $db_api_tracking->prepare('EXEC _Token @type = ?, @application_id = ?, @access_token = ?, @refresh_token = ?, @expire_in = ?, @status = ?, @createdatetime = ?, @createby = ?, @updatedatetime = ?, @updateby = ?');

                                $stmt->bindValue(1, 'Insert');
                                $stmt->bindValue(2, $__application['app_id']);
                                $stmt->bindValue(3, $access_token);
                                $stmt->bindValue(4, $refresh_token);
                                $stmt->bindValue(5, 28800);
                                $stmt->bindValue(6, 'Active');
                                $stmt->bindValue(7, $datetime_now);
                                $stmt->bindValue(8, 2);
                                $stmt->bindValue(9, $datetime_now);
                                $stmt->bindValue(10, 2);

                                $stmt->execute();

                                $__response_status_code = 200;
                                $__response_data = array(                                
                                    'access_token' => $access_token,
                                    'app_id' => $__application['app_id'],
                                    'expires_in' => 28800,
                                    'refresh_token' => $refresh_token,
                                    'token_type' => 'Bearer'
                                );
                            }
                            else
                            {
                                $__response_status_code = 401;
                                $__response_data = array(
                                    'error' => array(
                                        'errorType' => 'invalid_client',
                                        'message' => 'Refresh token invalid.'
                                    ),
                                    'success' => false
                                );
                            }
                        }
                        else
                        {
                            $__response_status_code = 401;
                            $__response_data = array(
                                'error' => array(
                                    'errorType' => 'invalid_client',
                                    'message' => 'Client id or Client secret invalid.'
                                ),
                                'success' => false
                            );
                        }
                    }
                }
                else
                {
                    $__response_status_code = 400;
                    $__response_data = array(
                        'error' => array(
                            'errorType' => 'invalid_request',
                            'fieldName' => 'grant_type',
                            'message' => 'grant_type invalid.'
                        ),
                        'success' => false
                    );
                }
            }
            else
            {
                $__response_status_code = 400;
                $__response_data = array(
                    'error' => array(
                        'errorType' => 'invalid_request',
                        'fieldName' => 'grant_type',
                        'message' => 'Missing parameters: grant_type'
                    ),
                    'success' => false
                );
            }

            $db_api_tracking->commit();
        }
        catch(Exception $ex)
        {
            $db_api_tracking->rollBack();

            $__response_status_code = 500;
            $__response_data = array(
                'error' => array(
                    'errorType' => 'internal_error',
                    'message' => $ex->getMessage()
                ),
                'success' => false
            );
        }

        return $res->withJson($__response_data, $__response_status_code);
    }
}