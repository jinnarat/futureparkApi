<?php

namespace App;

use \Psr\Container\ContainerInterface;
use \Psr\Http\Message\ServerRequestInterface as Request;
use \Psr\Http\Message\ResponseInterface as Response;

class Otp extends App
{
    public function __construct(ContainerInterface $container)
    {
        parent::__construct($container);
    }

    public function send(Request $req, Response $res, array $args)
    {
        $validate = true;
        $__response_status_code = 200;
        $__response_data = array();

        $db_cdpmkt = $this->db_cdpmkt;

        try
        {
            $db_cdpmkt->beginTransaction();

            $datetime_now = date('Y-m-d H:i:s');

            if($req->getHeader('Authorization'))
            {
                $req_authorization = $req->getHeader('Authorization')[0];
                $access_token = explode(' ', $req_authorization)[1];

                $__token = $this->validToken($access_token, $datetime_now);

                $__response_status_code = $__token['status'];
                $__response_data = $__token['data'];
            }
            else
            {
                $__response_status_code = 401;
                $__response_data = array(
                    'error' => array(
                        'errorType' => 'invalid_client',
                        'message' => 'Authorization header required.'
                    ),
                    'success' => false
                );
            }

            $req_body = $req->getParsedBody();

            $field = array(
                'chanel',
                'source',
                'type'
            );

            $_v = $this->isNullOrEmpty($field, $req_body);

            $__response_status_code = $_v['status'];
            $__response_data = $_v['detail'];

            if($__response_status_code == 200 && $req_body['chanel'] == 'sms')
            {
                if(!isset($req_body['mobile_no']))
                {
                    $__response_status_code = 400;
                    $__response_data = array(
                        'error' => array(
                            'errorType' => 'invalid_request',
                            'fieldName' => 'mobile_no',
                            'message' => 'Missing parameters: mobile_no'
                        ),
                        'success' => false
                    );
                }
                else if($req_body['mobile_no'] == '')
                {
                    $__response_status_code = 400;
                    $__response_data = array(
                        'error' => array(
                            'errorType' => 'invalid_request',
                            'fieldName' => 'mobile_no',
                            'message' => 'Missing mobile_no parameter value.'
                        ),
                        'success' => false
                    );
                }
            }

            if($__response_status_code == 200 && $req_body['chanel'] == 'email')
            {
                if(!isset($req_body['email']))
                {
                    $__response_status_code = 400;
                    $__response_data = array(
                        'error' => array(
                            'errorType' => 'invalid_request',
                            'fieldName' => 'email',
                            'message' => 'Missing parameters: email'
                        ),
                        'success' => false
                    );
                }
                else if($req_body['email'] == '')
                {
                    $__response_status_code = 400;
                    $__response_data = array(
                        'error' => array(
                            'errorType' => 'invalid_request',
                            'fieldName' => 'email',
                            'message' => 'Missing email parameter value.'
                        ),
                        'success' => false
                    );
                }
            }

            if($__response_status_code == 200 && $req_body['type'] == 'verify_phone')
            {
                if($req_body['chanel'] != 'sms')
                {
                    $__response_status_code = 400;
                    $__response_data = array(
                        'error' => array(
                            'errorType' => 'invalid_request',
                            'fieldName' => 'chanel',
                            'message' => 'chanel invalid.'
                        ),
                        'success' => false
                    );
                }
            }

            if($__response_status_code == 200 && $req_body['type'] == 'verify_email')
            {
                if($req_body['chanel'] != 'email')
                {
                    $__response_status_code = 400;
                    $__response_data = array(
                        'error' => array(
                            'errorType' => 'invalid_request',
                            'fieldName' => 'chanel',
                            'message' => 'chanel invalid.'
                        ),
                        'success' => false
                    );
                }
            }

            if($__response_status_code == 200)
            {
                $otp_message = NULL;
                $mobile_no = NULL;
                $mobile_full_no = NULL;
                $email = NULL;

                $_reponse = array();

                $otp = $this->generateRandomString(6, 'number');
                $ref = $this->generateRandomString(4);

                $expire_in = date('Y-m-d H:i:s', strtotime($datetime_now. ' +5 minutes'));

                if($req_body['type'] == 'verify_phone')
                {
                    if($req_body['chanel'] == 'sms')
                    {    
                        $mobile_full_no = $mobile_no = $req_body['mobile_no'];
    
                        if(substr($req_body['mobile_no'], 0, 1) == '0')
                        {
                            $mobile_full_no = '66' . substr($req_body['mobile_no'], 1, strlen($req_body['mobile_no']));
                        }
    
                        $otp_message = $this->otp_template['register'];
                        $otp_message = str_replace('{{otp}}', $otp, $otp_message);
                        $otp_message = str_replace('{{reff}}', $ref, $otp_message);
                        $otp_message = iconv(mb_detect_encoding($otp_message, mb_detect_order(), true), 'UTF-8', $otp_message);
                    }
                }
                else if($req_body['type'] == 'verify_email')
                {
                    if($req_body['chanel'] == 'email')
                    {    
                        $email = $req_body['email'];
    
                        $otp_message = $this->otp_template['verify_email'];
                        $otp_message = str_replace('{{otp}}', $otp, $otp_message);
                        $otp_message = str_replace('{{reff}}', $ref, $otp_message);
                        $otp_message = iconv(mb_detect_encoding($otp_message, mb_detect_order(), true), 'UTF-8', $otp_message);
                    }
                }
                else if($req_body['type'] == 'forgot_password')
                {
                    $mobile_no = (isset($req_body['mobile_no']) && $req_body['mobile_no'] != '') ? $req_body['mobile_no'] : NULL;
                    $email = (isset($req_body['email']) && $req_body['email'] != '') ? $req_body['email'] : NULL;

                    $stmt = $db_cdpmkt->prepare('EXEC _Person @type = ?, @mobile_no = ?, @email = ?, @status = ?, @is_member = ?');
        
                    $stmt->bindValue(1, 'Select');
                    $stmt->bindValue(2, $mobile_no);
                    $stmt->bindValue(3, $email);
                    $stmt->bindValue(4, 'A');
                    $stmt->bindValue(5, 'Y');

                    $stmt->execute();

                    $__person = $stmt->fetchAll();

                    if($mobile_no != NULL)
                    {
                        array_multisort(
                            array_column($__person, 'verify_phone'), SORT_DESC,
                            $__person
                        );
                    }

                    if($email != NULL)
                    {
                        array_multisort(
                            array_column($__person, 'verify_email'), SORT_DESC,
                            $__person
                        );
                    }

                    if(count($__person) > 0)
                    {
                        $__response_status_code = 202;

                        foreach($__person as $_p)
                        {
                            $is_member = ($_p['is_member'] == 'Y') ? true : false;

                            if($mobile_no != NULL)
                            {
                                $verify_phone = ($_p['verify_phone'] == 'Y') ? true : false;
                                $verify_email = false;
                            }

                            if($email != NULL)
                            {
                                $verify_phone = false;
                                $verify_email = ($_p['verify_email'] == 'Y') ? true : false;
                            }
    
                            if($is_member && ($verify_phone || $verify_email))
                            {
                                $otp_message = $this->otp_template['forgot_password'];
        
                                if($req_body['chanel'] == 'sms')
                                {
                                    $mobile_full_no = $mobile_no = $req_body['mobile_no'];
                
                                    if(substr($req_body['mobile_no'], 0, 1) == '0')
                                    {
                                        $mobile_full_no = '66' . substr($req_body['mobile_no'], 1, strlen($req_body['mobile_no']));
                                    }
            
                                    $otp_message = str_replace('{{chanel}}', 'เบอร์โทรศัพท์', $otp_message);
                                    $otp_message = str_replace('{{otp}}', $otp, $otp_message);
                                    $otp_message = str_replace('{{reff}}', $ref, $otp_message);
                                    $otp_message = iconv(mb_detect_encoding($otp_message, mb_detect_order(), true), 'UTF-8', $otp_message);
                                }
                                else if($req_body['chanel'] == 'email')
                                {
                                    $email = $req_body['email'];
                                    
                                    $otp_message = str_replace('{{chanel}}', 'อีเมล', $otp_message);
                                    $otp_message = str_replace('{{otp}}', $otp, $otp_message);
                                    $otp_message = str_replace('{{reff}}', $ref, $otp_message);
                                    $otp_message = iconv(mb_detect_encoding($otp_message, mb_detect_order(), true), 'UTF-8', $otp_message);   
                                }                                

                                $__response_status_code = 200;
                                break;
                            }
    
                            // if($mobile_no != '' && $__person['verify_phone'] != 'Y')
                            // {
                            //     $__response_status_code = 200;
                            //     $__response_data = array(
                            //         'response_body' => array(
                            //             'message' => 'Mobile number is not verify.'
                            //         ),
                            //         'success' => false
                            //     );
        
                            //     $validate = false;
                            // }
                            // else if($email != '' && $__person['verify_email'] != 'Y')
                            // {
                            //     $__response_status_code = 200;
                            //     $__response_data = array(
                            //         'response_body' => array(
                            //             'message' => 'Email is not verify.'
                            //         ),
                            //         'success' => false
                            //     );
        
                            //     $validate = false;
                            // }
                        }

                        if($__response_status_code == 202)
                        {
                            if($mobile_no != NULL)
                            {
                                $__response_status_code = 200;
                                $__response_data = array(
                                    'response_body' => array(
                                        'message' => 'Mobile number is not verify.'
                                    ),
                                    'success' => false
                                );
        
                                $validate = false;
                            }

                            if($email != NULL)
                            {
                                $__response_status_code = 200;
                                $__response_data = array(
                                    'response_body' => array(
                                        'message' => 'Email is not verify.'
                                    ),
                                    'success' => false
                                );
        
                                $validate = false;
                            }
                        }
                    }
                    else
                    {
                        $__response_status_code = 404;
                        $__response_data = array(
                            'response_body' => array(
                                'message' => 'Member not found.'
                            ),
                            'success' => false
                        );

                        $validate = false;
                    }
                }
                else
                {
                    $__response_status_code = 400;
                    $__response_data = array(
                        'error' => array(
                            'errorType' => 'invalid_request',
                            'fieldName' => 'type',
                            'message' => 'type invalid.'
                        ),
                        'success' => false
                    );
                }

                if($__response_status_code == 200 && $validate)
                {
                    if($req_body['chanel'] == 'sms')
                    {
                        if($this->sms['enable'])
                        {				
                            $_reponse = $this->sendSMS($mobile_full_no , $otp_message);
                        }
                        else
                        {
                            $_reponse['response'] = 200;
                            $_reponse['description'] = 'Request was successful (all recipients)';
                        }
                    }
                    else if($req_body['chanel'] == 'email')
                    {
                        if($this->smtp['enable'])
                        {
                            $_reponse = $this->sendEmail($req_body['email'], 'Future Park Support', $otp_message);
                        }
                        else
                        {
                            $_reponse['response'] = 200;
                            $_reponse['description'] = 'Request was successful (all recipients)';
                        }
                    }
                    else
                    {
                        $__response_status_code = 400;
                        $__response_data = array(
                            'error' => array(
                                'errorType' => 'invalid_request',
                                'fieldName' => 'chanel',
                                'message' => 'chanel invalid.'
                            ),
                            'success' => false
                        );
                    }
                }

                if(isset($_reponse) && isset($_reponse['response']) || (isset($_reponse['status']) && $_reponse['status'] == 0))
                {
                    $stmt = $db_cdpmkt->prepare('EXEC _Log_SMS @type = ?, @ref_code = ?, @sms_chanel = ?, @mobile_no = ?, @status = ?');

                    $stmt->bindValue(1, 'Update');
                    $stmt->bindValue(2, $req_body['source']);
                    $stmt->bindValue(3, $req_body['chanel']);
                    $stmt->bindValue(4, $mobile_no);
                    $stmt->bindValue(5, 'Expire');
                    
                    $stmt->execute();

                    $stmt = $db_cdpmkt->prepare('EXEC _Log_SMS @type = ?, @ref_id = ?, @ref_code = ?, @sms_chanel = ?, @mobile_no = ?, @mobile_full_no = ?, @email = ?, @otp = ?, @reference = ?, @message = ?, @reponse = ?, @description = ?, @status = ?, @userby = ?, @usedtime = ?, @starttime = ?, @endtime = ?');

                    $stmt->bindValue(1, 'Insert');
                    $stmt->bindValue(2, NULL);
                    $stmt->bindValue(3, $req_body['source']);
                    $stmt->bindValue(4, $req_body['chanel']);
                    $stmt->bindValue(5, $mobile_no);
                    $stmt->bindValue(6, $mobile_full_no);
                    $stmt->bindValue(7, $email);
                    $stmt->bindValue(8, $otp);
                    $stmt->bindValue(9, $ref);
                    $stmt->bindValue(10, $otp_message);
                    $stmt->bindValue(11, isset($_reponse['response']) ? $_reponse['response'] : NULL);
                    $stmt->bindValue(12, isset($_reponse['description']) ? $_reponse['description'] : NULL);
                    $stmt->bindValue(13, 'Send');
                    $stmt->bindValue(14, NULL);
                    $stmt->bindValue(15, NULL);
                    $stmt->bindValue(16, $datetime_now);
                    $stmt->bindValue(17, $expire_in);
    
                    $stmt->execute();
    
                    if($_reponse['response'] == 500)
                    {
                        $__response_status_code = 500;
                        $__response_data = array(
                            'error' => array(
                                'errorType' => 'internal_error',
                                'message' => $_reponse['description']
                            ),
                            'success' => false
                        );
                    }
                    else
                    {    
                        $__response_status_code = 200;
                        $__response_data = array(
                            'response_body' => array(                        
                                'expire_datetime' => $expire_in,
                                'chanel' => $req_body['chanel'],
                                'otp' => $otp,
                                'ref' => $ref,
                                'request_datetime' => $datetime_now
                            ),
                            'success' => true
                        );
    
                        if($req_body['chanel'] == 'sms')
                        {
                            $__response_data['response_body']['mobile_no'] = $req_body['mobile_no'];
                        }
                        else if($req_body['chanel'] == 'email')
                        {
                            $__response_data['response_body']['email'] = $req_body['email'];
                        }
                    }
                }
                else if(isset($_reponse['status']) && $_reponse['status'] != 0)
                {
                    $__response_status_code = 500;
                    $__response_data = array(
                        'error' => array(
                            'errorType' => 'internal_error',
                            'message' => $_reponse['description']
                        ),
                        'success' => false
                    );
                }
            }

            $db_cdpmkt->commit();
        }
        catch(Exception $ex)
        {
            $db_cdpmkt->rollBack();

            $__response_status_code = 500;
            $__response_data = array(
                'error' => array(
                    'errorType' => 'internal_error',
                    'message' => $ex->getMessage()
                ),
                'success' => false
            );
        }

        return $res->withJson($__response_data, $__response_status_code);
    }

    public function verify(Request $req, Response $res, array $args)
    {
        $__response_status_code = 200;
        $__response_data = array();

        $db_cdpmkt = $this->db_cdpmkt;

        try
        {
            $db_cdpmkt->beginTransaction();

            $datetime_now = date('Y-m-d H:i:s');

            $req_body = $req->getParsedBody();

            if($req->getHeader('Authorization'))
            {
                $req_authorization = $req->getHeader('Authorization')[0];
                $access_token = explode(' ', $req_authorization)[1];

                $__token = $this->validToken($access_token, $datetime_now);

                $__response_status_code = $__token['status'];
                $__response_data = $__token['data'];
            }
            else
            {
                $__response_status_code = 401;
                $__response_data = array(
                    'error' => array(
                        'errorType' => 'invalid_client',
                        'message' => 'Authorization header required.'
                    ),
                    'success' => false
                );
            }

            if($__response_status_code == 200 && !isset($req_body['chanel']))
            {
                $__response_status_code = 400;
                $__response_data = array(
                    'error' => array(
                        'errorType' => 'invalid_request',
                        'fieldName' => 'chanel',
                        'message' => 'Missing parameters: chanel'
                    ),
                    'success' => false
                );
            }

            if($__response_status_code == 200 && $req_body['chanel'] == '')
            {
                $__response_status_code = 400;
                $__response_data = array(
                    'error' => array(
                        'errorType' => 'invalid_request',
                        'fieldName' => 'chanel',
                        'message' => 'Missing chanel parameter value.'
                    ),
                    'success' => false
                );
            }

            if($__response_status_code == 200 && $req_body['chanel'] == 'sms')
            {
                if(!isset($req_body['mobile_no']))
                {
                    $__response_status_code = 400;
                    $__response_data = array(
                        'error' => array(
                            'errorType' => 'invalid_request',
                            'fieldName' => 'mobile_no',
                            'message' => 'Missing parameters: mobile_no'
                        ),
                        'success' => false
                    );
                }
                else if($req_body['mobile_no'] == '')
                {
                    $__response_status_code = 400;
                    $__response_data = array(
                        'error' => array(
                            'errorType' => 'invalid_request',
                            'fieldName' => 'mobile_no',
                            'message' => 'Missing mobile_no parameter value.'
                        ),
                        'success' => false
                    );
                }
            }

            if($__response_status_code == 200 && $req_body['chanel'] == 'email')
            {
                if(!isset($req_body['email']))
                {
                    $__response_status_code = 400;
                    $__response_data = array(
                        'error' => array(
                            'errorType' => 'invalid_request',
                            'fieldName' => 'email',
                            'message' => 'Missing parameters: email'
                        ),
                        'success' => false
                    );
                }
                else if($req_body['email'] == '')
                {
                    $__response_status_code = 400;
                    $__response_data = array(
                        'error' => array(
                            'errorType' => 'invalid_request',
                            'fieldName' => 'email',
                            'message' => 'Missing email parameter value.'
                        ),
                        'success' => false
                    );
                }
            }

            if($__response_status_code == 200 && !isset($req_body['source']))
            {
                $__response_status_code = 400;
                $__response_data = array(
                    'error' => array(
                        'errorType' => 'invalid_request',
                        'fieldName' => 'source',
                        'message' => 'Missing parameters: source'
                    ),
                    'success' => false
                );
            }

            if($__response_status_code == 200 && $req_body['source'] == '')
            {
                $__response_status_code = 400;
                $__response_data = array(
                    'error' => array(
                        'errorType' => 'invalid_request',
                        'fieldName' => 'source',
                        'message' => 'Missing source parameter value.'
                    ),
                    'success' => false
                );
            }

            if($__response_status_code == 200 && !isset($req_body['otp']))
            {
                $__response_status_code = 400;
                $__response_data = array(
                    'error' => array(
                        'errorType' => 'invalid_request',
                        'fieldName' => 'otp',
                        'message' => 'Missing parameters: otp'
                    ),
                    'success' => false
                );
            }

            if($__response_status_code == 200 && $req_body['otp'] == '')
            {
                $__response_status_code = 400;
                $__response_data = array(
                    'error' => array(
                        'errorType' => 'invalid_request',
                        'fieldName' => 'otp',
                        'message' => 'Missing otp parameter value.'
                    ),
                    'success' => false
                );
            }

            if($__response_status_code == 200 && !isset($req_body['ref']))
            {
                $__response_status_code = 400;
                $__response_data = array(
                    'error' => array(
                        'errorType' => 'invalid_request',
                        'fieldName' => 'ref',
                        'message' => 'Missing parameters: ref'
                    ),
                    'success' => false
                );
            }

            if($__response_status_code == 200 && $req_body['ref'] == '')
            {
                $__response_status_code = 400;
                $__response_data = array(
                    'error' => array(
                        'errorType' => 'invalid_request',
                        'fieldName' => 'ref',
                        'message' => 'Missing ref parameter value.'
                    ),
                    'success' => false
                );
            }

            $stmt = $db_cdpmkt->prepare('EXEC _Log_SMS @type = ?, @ref_id = ?, @ref_code = ?, @sms_chanel = ?, @mobile_no = ?, @email = ?, @otp = ?, @reference = ?, @status = ?');

            $stmt->bindValue(1, 'Select');
            $stmt->bindValue(2, NULL);
            $stmt->bindValue(3, $req_body['source']);
            $stmt->bindValue(4, $req_body['chanel']);
            $stmt->bindValue(5, isset($req_body['mobile_no']) ? $req_body['mobile_no'] : NULL);
            $stmt->bindValue(6, isset($req_body['email']) ? $req_body['email'] : NULL);
            $stmt->bindValue(7, $req_body['otp']);
            $stmt->bindValue(8, $req_body['ref']);
            $stmt->bindValue(9, 'Send');

            $stmt->execute();

            $_otp = $stmt->fetch();

            if(isset($_otp['logId']) && isset($_otp['logId']) != '')
            {
                if($datetime_now <= $_otp['endtime'])
                {
                    if(isset($req_body['mobile_no']))
                    {
                        $userby = $req_body['mobile_no'];
                    }

                    if(isset($req_body['email']))
                    {
                        $userby = $req_body['email'];
                    }

                    $stmt = $db_cdpmkt->prepare('EXEC _Log_SMS @type = ?, @ref_id = ?, @ref_code = ?, @sms_chanel = ?, @mobile_no = ?, @email = ?, @otp = ?, @reference = ?, @status = ?, @userby = ?, @usedtime = ?');

                    $stmt->bindValue(1, 'Update');
                    $stmt->bindValue(2, NULL);
                    $stmt->bindValue(3, $req_body['source']);
                    $stmt->bindValue(4, $req_body['chanel']);
                    $stmt->bindValue(5, isset($req_body['mobile_no']) ? $req_body['mobile_no'] : NULL);
                    $stmt->bindValue(6, isset($req_body['email']) ? $req_body['email'] : NULL);
                    $stmt->bindValue(7, $req_body['otp']);
                    $stmt->bindValue(8, $req_body['ref']);
                    $stmt->bindValue(9, 'Used');
                    $stmt->bindValue(10, $userby);
                    $stmt->bindValue(11, $datetime_now);

                    $stmt->execute();

                    $__response_status_code = 200;
                    $__response_data = array(
                        'response_body' => array(
                            'message' => 'Verify success.'
                        ),
                        'success' => true
                    );
                }
                else
                {
                    $stmt = $db_cdpmkt->prepare('EXEC _Log_SMS @type = ?, @ref_id = ?, @ref_code = ?, @sms_chanel = ?, @mobile_no = ?, @email = ?, @otp = ?, @reference = ?, @status = ?');

                    $stmt->bindValue(1, 'Update');
                    $stmt->bindValue(2, NULL);
                    $stmt->bindValue(3, $req_body['source']);
                    $stmt->bindValue(4, $req_body['chanel']);
                    $stmt->bindValue(5, isset($req_body['mobile_no']) ? $req_body['mobile_no'] : NULL);
                    $stmt->bindValue(6, isset($req_body['email']) ? $req_body['email'] : NULL);
                    $stmt->bindValue(7, $req_body['otp']);
                    $stmt->bindValue(8, $req_body['ref']);
                    $stmt->bindValue(9, 'Expire');

                    $stmt->execute();

                    $__response_status_code = 200;
                    $__response_data = array(
                        'response_body' => array(
                            'message' => 'OTP expire.'
                        ),
                        'success' => false
                    );
                }
            }
            else
            {
                $__response_status_code = 200;
                $__response_data = array(
                    'response_body' => array(
                        'message' => 'Verify fail.'
                    ),
                    'success' => false
                );
            }

            $db_cdpmkt->commit();
        }
        catch(Exception $ex)
        {
            $db_cdpmkt->rollBack();

            $__response_status_code = 500;
            $__response_data = array(
                'error' => array(
                    'errorType' => 'internal_error',
                    'message' => $ex->getMessage()
                ),
                'success' => false
            );
        }

        return $res->withJson($__response_data, $__response_status_code);
    }
}