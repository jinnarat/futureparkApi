<?php

namespace App;

use \Psr\Container\ContainerInterface;
use \Psr\Http\Message\ServerRequestInterface as Request;
use \Psr\Http\Message\ResponseInterface as Response;

class Person extends App
{
    public function __construct(ContainerInterface $container)
    {
        parent::__construct($container);
    }

    public function check_line_id(Request $req, Response $res, array $args)
    {
        $__response_status_code = 200;
        $__response_data = array();

        $db_cdpmkt = $this->db_cdpmkt;

        try
        {
            $datetime_now = date('Y-m-d H:i:s');

            if($req->getHeader('Authorization'))
            {
                $req_authorization = $req->getHeader('Authorization')[0];
                $access_token = explode(' ', $req_authorization)[1];

                $__token = $this->validToken($access_token, $datetime_now);

                $__response_status_code = $__token['status'];
                $__response_data = $__token['data'];
            }
            else
            {
                $__response_status_code = 401;
                $__response_data = array(
                    'error' => array(
                        'errorType' => 'invalid_client',
                        'message' => 'Authorization header required.'
                    ),
                    'success' => false
                );

                return $res->withJson($__response_data, $__response_status_code);
            }

            $req_body = $req->getParsedBody();

            $field = array(
                'mobile_no'
            );

            $_v = $this->isNullOrEmpty($field, $req_body);

            $__response_status_code = $_v['status'];
            $__response_data = $_v['detail'];

            if($__response_status_code == 200)
            {
                $mobile_no = (isset($req_body['mobile_no']) ? $req_body['mobile_no'] : NULL);
                $id_card_no = (isset($req_body['id_card_no']) ? $req_body['id_card_no'] : NULL);
                $passport_no = (isset($req_body['passport_no']) ? $req_body['passport_no'] : NULL);

                if(empty($id_card_no) && empty($passport_no))
                {
                    $__response_status_code = 400;
                    $__response_data = array(
                        'error' => array(
                            'errorType' => 'invalid_request',
                            'fieldName' => 'id_card_no, passport_no',
                            'message' => 'Missing parameters: id_card_no, passport_no'
                        ),
                        'success' => false
                    );

                    return $res->withJson($__response_data, $__response_status_code);
                }

                if(isset($req_body['id_card_no']) && empty($id_card_no))
                {
                    $__response_status_code = 400;
                    $__response_data = array(
                        'error' => array(
                            'errorType' => 'invalid_request',
                            'fieldName' => 'id_card_no',
                            'message' => 'Missing id_card_no parameter value.'
                        ),
                        'success' => false
                    );

                    return $res->withJson($__response_data, $__response_status_code);
                }

                if(isset($req_body['passport_no']) && empty($passport_no))
                {
                    $__response_status_code = 400;
                    $__response_data = array(
                        'error' => array(
                            'errorType' => 'invalid_request',
                            'fieldName' => 'passport_no',
                            'message' => 'Missing passport_no parameter value.'
                        ),
                        'success' => false
                    );

                    return $res->withJson($__response_data, $__response_status_code);
                }

                $stmt = $db_cdpmkt->prepare('EXEC _Person @type = ?, @mobile_no = ?, @id_card = ?, @passport = ?, @is_member_number = ?, @status = ?');

                $stmt = $this->bindValue($stmt, array(
                    'type' => 'Profile',
                    'mobile_no' => $mobile_no,
                    'id_card' => $id_card_no,
                    'passport' => $passport_no,
                    'is_member_number' => 'Y',
                    'status' => 'A'
                ));

                $stmt->execute();

                $_person = $stmt->fetchAll();

                if(count($_person) > 0)
                {
                    array_multisort(
                        array_column($_person, 'verify_phone'), SORT_DESC,
                        $_person
                    );

                    $verify_phone = '';
                    $is_member = '';

                    $member = array();

                    foreach($_person as $_p)
                    {
                        $is_member = ($_p['is_member'] == 'Y') ? true : false;
                        $verify_phone = ($_p['verify_phone'] == 'Y') ? true : false;

                        $firstname = ($_p['firstname'] == null) ? '' : $_p['firstname'];
                        $lastname = ($_p['lastname'] == null) ? '' : $_p['lastname'];
                        $email = ($_p['email'] == null) ? '' : $_p['email'];
                        $date_of_birth = ($_p['birthdate'] == null) ? '' : $_p['birthdate'];

                        if($_p['gender'] == 'M')
                        {
                            $gender = 'Male';
                        }
                        else if($_p['gender'] == 'F')
                        {
                            $gender = 'Female';
                        }
                        else
                        {
                            $gender = '';
                        }

                        $id_card_no = ($_p['idCardNo'] == null) ? '' : $_p['idCardNo'];
                        $naiotality_code = ($_p['nationCode'] == null) ? '' : $_p['nationCode'];
                        $naiotality = ($_p['nationNameThai'] == null) ? '' : $_p['nationNameThai'];
                        $passport_no = ($_p['passportNo'] == null) ? '' : $_p['passportNo'];
                        $member_number = ($_p['memberNo'] == null) ? '' : $_p['memberNo'];
                        $member_number_ref = ($_p['memberNoRef'] == null) ? '' : $_p['memberNoRef'];
                        $line_user_id = ($_p['line_user_id'] == null) ? '' : $_p['line_user_id'];
                        $line_user_id_old = ($_p['line_user_id_old'] == null) ? '' : $_p['line_user_id_old'];
                        $is_consent = ($_p['is_consent'] == 'Y') ? true : false;
                        $is_subscribe = ($_p['preferredChannel'] == 'Email') ? true : false;

                        $member[] = array(
                            'id' => (int)$_p['personId'],
                            'firstname' => $firstname,
                            'lastname' => $lastname,
                            'date_of_birth' => $date_of_birth,
                            'email' => $email,
                            'gender' => $gender,
                            'id_card_no' => $id_card_no,
                            'member_number' => $member_number,
                            'member_number_ref' => $member_number_ref,
                            'nationality_code' => $naiotality_code,
                            'nationality' => $naiotality,
                            'passport_no' => $passport_no,
                            'line_user_id' => $line_user_id,
                            'line_user_id_old' => $line_user_id_old,
                            'consent' => $is_consent,
                            'is_member' => $is_member,
                            'subscribe' => $is_subscribe,
                            'verify_phone' => $verify_phone
                        );

                        if($verify_phone)
                        {
                            break;
                        }
                    }

                    $__response_data = array(
                        'response_body' => array(
                            'person' => $member
                        ),
                        'success' => true
                    );
                }
                else
                {
                    $__response_data = array(
                        'response_body' => array(
                            'message' => 'Member not found.'
                        ),
                        'success' => false
                    );
                }
            }
            else
            {
                return $res->withJson($__response_data, $__response_status_code);
            }
        }
        catch(Exception $ex)
        {
            $__response_status_code = 500;
            $__response_data = array(
                'error' => array(
                    'errorType' => 'internal_error',
                    'message' => $ex->getMessage()
                ),
                'success' => false
            );
        }

        return $res->withJson($__response_data, $__response_status_code);
    }

    public function check_status(Request $req, Response $res, array $args)
    {
        $__response_status_code = 200;
        $__response_data = array();

        $db_cdpmkt = $this->db_cdpmkt;

        try
        {
            $datetime_now = date('Y-m-d H:i:s');

            if($req->getHeader('Authorization'))
            {
                $req_authorization = $req->getHeader('Authorization')[0];
                $access_token = explode(' ', $req_authorization)[1];

                $__token = $this->validToken($access_token, $datetime_now);

                $__response_status_code = $__token['status'];
                $__response_data = $__token['data'];
            }
            else
            {
                $__response_status_code = 401;
                $__response_data = array(
                    'error' => array(
                        'errorType' => 'invalid_client',
                        'message' => 'Authorization header required.'
                    ),
                    'success' => false
                );

                return $res->withJson($__response_data, $__response_status_code);
            }

            $req_body = $req->getParsedBody();

            if($__response_status_code == 200 && !isset($req_body['mobile_no']) && !isset($req_body['email']))
            {
                $__response_status_code = 400;
                $__response_data = array(
                    'error' => array(
                        'errorType' => 'invalid_request',
                        'fieldName' => 'mobile_no',
                        'message' => 'Missing parameters: mobile_no'
                    ),
                    'success' => false
                );
            }
            
            if($__response_status_code == 200 && isset($req_body['mobile_no']) && $req_body['mobile_no'] == '')
            {
                $__response_status_code = 400;
                $__response_data = array(
                    'error' => array(
                        'errorType' => 'invalid_request',
                        'fieldName' => 'mobile_no',
                        'message' => 'Missing mobile_no parameter value.'
                    ),
                    'success' => false
                );
            }

            if($__response_status_code == 200 && isset($req_body['email']) && $req_body['email'] == '')
            {
                $__response_status_code = 400;
                $__response_data = array(
                    'error' => array(
                        'errorType' => 'invalid_request',
                        'fieldName' => 'email',
                        'message' => 'Missing email parameter value.'
                    ),
                    'success' => false
                );
            }

            if($__response_status_code == 200)
            {
                $person_id = (isset($req_body['id']) && $req_body['id'] != '') ? $req_body['id'] : NULL;
                $mobile_no = (isset($req_body['mobile_no']) && $req_body['mobile_no'] != '') ? $req_body['mobile_no'] : NULL;
                $email = (isset($req_body['email']) && $req_body['email'] != '') ? $req_body['email'] : NULL;
                $exclude_status = (isset($req_body['exclude_status']) && $req_body['exclude_status'] != '') ? $req_body['exclude_status'] : NULL;

                $stmt = $db_cdpmkt->prepare('EXEC _Person @type = ?, @mobile_no = ?, @email = ?, @status = ?, @exclude_person_status = ?, @person_id = ?');

                $stmt->bindValue(1, 'Select');
                $stmt->bindValue(2, $mobile_no);
                $stmt->bindValue(3, $email);
                $stmt->bindValue(4, ($exclude_status == '' ? 'A' : NULL));
                $stmt->bindValue(5, $exclude_status);
                $stmt->bindValue(6, $person_id);

                $stmt->execute();

                $_person = $stmt->fetchAll();

                $__response_status_code = 200;

                if(count($_person) > 0)
                {
                    if($mobile_no != NULL)
                    {
                        array_multisort(
                            array_column($_person, 'verify_phone'), SORT_DESC,
                            $_person
                        );
                    }

                    if($email != NULL)
                    {
                        array_multisort(
                            array_column($_person, 'verify_email'), SORT_DESC,
                            $_person
                        );
                    }

                    $verify_phone = '';
                    $is_member = '';
                    $verify_email = '';

                    $member = array();
                    
                    foreach($_person as $_p)
                    {
                        if($is_member == '' && $verify_phone == '' && $verify_email == '')
                        {
                            $is_member = ($_p['is_member'] == 'Y') ? true : false;
                            $verify_phone = ($_p['verify_phone'] == 'Y') ? true : false;
                            $verify_email = ($_p['verify_email'] == 'Y') ? true : false;
                        }

                        $firstname = ($_p['firstname'] == null) ? '' : $_p['firstname'];
                        $lastname = ($_p['lastname'] == null) ? '' : $_p['lastname'];
                        $email = ($_p['email'] == null) ? '' : $_p['email'];
                        $date_of_birth = ($_p['birthdate'] == null) ? '' : $_p['birthdate'];

                        if($_p['gender'] == 'M')
                        {
                            $gender = 'Male';
                        }
                        else if($_p['gender'] == 'F')
                        {
                            $gender = 'Female';
                        }
                        else
                        {
                            $gender = '';
                        }

                        $id_card_no = ($_p['idCardNo'] == null) ? '' : $_p['idCardNo'];
                        $naiotality_code = ($_p['nationCode'] == null) ? '' : $_p['nationCode'];
                        $naiotality = ($_p['nationNameThai'] == null) ? '' : $_p['nationNameThai'];
                        $passport_no = ($_p['passportNo'] == null) ? '' : $_p['passportNo'];
                        $member_number_ref = ($_p['memberNoRef'] == null) ? '' : $_p['memberNoRef'];
                        $is_consent = ($_p['is_consent'] == 'Y') ? true : false;
                        $is_subscribe = ($_p['preferredChannel'] == 'Email') ? true : false;

                        $member[] = array(
                            'id' => (int)$_p['personId'],
                            'firstname' => $firstname,
                            'lastname' => $lastname,
                            'date_of_birth' => $date_of_birth,
                            'email' => $email,
                            'gender' => $gender,
                            'id_card_no' => $id_card_no,
                            'member_number_ref' => $member_number_ref,
                            'consent' => $is_consent,
                            'subscribe' => $is_subscribe,
                            'nationality_code' => $naiotality_code,
                            'nationality' => $naiotality,
                            'passport_no' => $passport_no
                        );

                        if($mobile_no != NULL)
                        {
                            if($is_member || $verify_phone)
                            {
                                break;
                            }

                            if($is_member || $verify_email)
                            {
                                break;
                            }
                        }

                        if($email != NULL)
                        {
                            if($is_member || $verify_email)
                            {
                                break;
                            }

                            if($is_member || $verify_phone)
                            {
                                break;
                            }
                        }
                    }

                    $__response_data = array(
                        'response_body' => array(
                            'is_member' => $is_member,
                            'verify_phone' => $verify_phone,
                            'verify_email' => $verify_email,
                            'person' => $member
                        ),
                        'success' => true
                    );
                }
                else
                {
                    $__response_data = array(
                        'response_body' => array(
                            'message' => 'Member not found.'
                        ),
                        'success' => false
                    );
                }
            }
        }
        catch(Exception $ex)
        {
            $__response_status_code = 500;
            $__response_data = array(
                'error' => array(
                    'errorType' => 'internal_error',
                    'message' => $ex->getMessage()
                ),
                'success' => false
            );
        }

        return $res->withJson($__response_data, $__response_status_code);
    }

    public function register(Request $req, Response $res, array $args)
    {
        $__response_status_code = 200;
        $__response_data = array();

        $db_cdpmkt = $this->db_cdpmkt;

        try
        {
            $db_cdpmkt->beginTransaction();

            $datetime_now = date('Y-m-d H:i:s');

            if($req->getHeader('Authorization'))
            {
                $req_authorization = $req->getHeader('Authorization')[0];
                $access_token = explode(' ', $req_authorization)[1];

                $__token = $this->validToken($access_token, $datetime_now);

                $__response_status_code = $__token['status'];
                $__response_data = $__token['data'];
            }
            else
            {
                $__response_status_code = 401;
                $__response_data = array(
                    'error' => array(
                        'errorType' => 'invalid_client',
                        'message' => 'Authorization header required.'
                    ),
                    'success' => false
                );

                return $res->withJson($__response_data, $__response_status_code);
            }

            $req_body = $req->getParsedBody();

            $career = (isset($req_body['career']) ? $req_body['career'] : NULL);
            $career_level = (isset($req_body['career_level']) ? $req_body['career_level'] : NULL);
            $chanel = (isset($req_body['chanel']) ? $req_body['chanel'] : NULL);
            $consent = (isset($req_body['consent']) ? ($req_body['consent'] === 'true' ? 'Y' : 'N') : NULL);
            $device = (isset($req_body['device']) ? $req_body['device'] : NULL);
            $date_of_birth = (isset($req_body['date_of_birth']) ? $req_body['date_of_birth'] : NULL);
            $education_id = (isset($req_body['education_id']) ? $req_body['education_id'] : NULL);
            $email = (isset($req_body['email']) ? $req_body['email'] : NULL);
            $firstname = (isset($req_body['firstname']) ? $req_body['firstname'] : NULL);
            $gender = (isset($req_body['gender']) ? ($req_body['gender'] == 'Male' ? 'M' : ($req_body['gender'] == 'Female' ? 'F' : NULL)) : NULL);
            $id_card_no = (isset($req_body['id_card_no']) ? $req_body['id_card_no'] : NULL);
            $is_member = (isset($req_body['is_member']) ? $req_body['is_member'] : NULL);
            $lastname = (isset($req_body['lastname']) ? $req_body['lastname'] : NULL);
            $line_user_id = (isset($req_body['line_user_id']) ? $req_body['line_user_id'] : NULL);
            $line_display_name = (isset($req_body['line_display_name']) ? $req_body['line_display_name'] : NULL);
            $line_picture_url = (isset($req_body['line_picture_url']) ? $req_body['line_picture_url'] : NULL);
            $line_status_message = (isset($req_body['line_status_message']) ? $req_body['line_status_message'] : NULL);
            $member_number_ref = (isset($req_body['member_number_ref']) ? $req_body['member_number_ref'] : NULL);
            $register_status = (isset($req_body['member_number_ref']) ? ($req_body['member_number_ref'] != '' ? 'Existing' : 'New') : 'New');
            $member_status = (isset($req_body['member_status']) ? $req_body['member_status'] : NULL);
            $mobile_no = (isset($req_body['mobile_no']) ? $req_body['mobile_no'] : NULL);
            $nationality = (isset($req_body['nationality']) ? $req_body['nationality'] : NULL);
            $not_idcard = (isset($req_body['not_idcard']) ? $req_body['not_idcard'] : NULL);
            $not_phone = (isset($req_body['not_phone']) ? $req_body['not_phone'] : NULL);
            $number_of_child = (isset($req_body['number_of_child']) ? $req_body['number_of_child'] : NULL);
            $number_of_family = (isset($req_body['number_of_family']) ? $req_body['number_of_family'] : NULL);
            $occupation = (isset($req_body['occupation']) ? $req_body['occupation'] : NULL);
            $old_tier_id = NULL;
            $passport_no = (isset($req_body['passport_no']) ? $req_body['passport_no'] : NULL);
            $password = (isset($req_body['password']) ? hash('sha256', $req_body['password']) : NULL);
            $person_id = (isset($req_body['id']) ? $req_body['id'] : NULL);
            $person_status = (isset($req_body['person_status']) ? $req_body['person_status'] : NULL);
            $point = (isset($req_body['point']) ? $req_body['point'] : 0);
            $point_bonus = (isset($req_body['point_bonus']) ? $req_body['point_bonus'] : 0);
            $point_accumulate = (isset($req_body['point_accumulate']) ? $req_body['point_accumulate'] : 0);
            $point_spending = (isset($req_body['point_spending']) ? $req_body['point_spending'] : 0);
            $point_balance = (isset($req_body['point_balance']) ? $req_body['point_balance'] : 0);
            $preferred_channel = (isset($req_body['preferred_channel']) ? $req_body['preferred_channel'] : NULL);
            $religion = (isset($req_body['religion']) ? $req_body['religion'] : NULL);
            $register_type = (isset($req_body['register_type']) ? $req_body['register_type'] : NULL);
            $remark = (isset($req_body['remark']) ? $req_body['remark'] : NULL);
            $salary = (isset($req_body['salary']) ? $req_body['salary'] : NULL);
            $session_id = (isset($req_body['session_id']) ? $req_body['session_id'] : NULL);
            $subscribe = (isset($req_body['subscribe']) ? ($req_body['subscribe'] === 'true' ? 'Email' : NULL) : NULL);
            $tier_id = (isset($req_body['tier_id']) ? $req_body['tier_id'] : NULL);
            $verify_id_card = (isset($req_body['verify_id_card']) ? ($req_body['verify_id_card'] === 'true' ? 'Y' : NULL) : NULL);
            $verify_email = (isset($req_body['verify_email']) ? ($req_body['verify_email'] === 'true' ? 'Y' : NULL) : NULL);
            $verify_phone = (isset($req_body['verify_phone']) ? ($req_body['verify_phone'] === 'true' ? 'Y' : NULL) : NULL);            
            $user_id = (isset($req_body['user_id']) ? $req_body['user_id'] : 1122);

            if($chanel == 'Employee')
            {
                $field = array(
                    'chanel',
                    'consent',
                    'date_of_birth',
                    'device',
                    'firstname',
                    'gender',
                    'lastname',
                    'mobile_no',
                    'nationality'
                );
            }
            else
            {
                $field = array(
                    'chanel',
                    'consent',
                    'date_of_birth',
                    'device',
                    'firstname',
                    'gender',
                    'lastname',
                    'mobile_no',
                    'nationality',
                    'password',
                    'session_id',
                    'subscribe'
                );
            }

            $_v = $this->isNullOrEmpty($field, $req_body);

            $__response_status_code = $_v['status'];
            $__response_data = $_v['detail'];

            if(empty($date_of_birth) && !$this->validateDate($date_of_birth))
            {
                $__response_status_code = 400;
                $__response_data = array(
                    'error' => array(
                        'errorType' => 'invalid_request',
                        'fieldName' => 'date_of_birth',
                        'message' => 'date_of_birth invalid.'
                    ),
                    'success' => false
                );

                return $res->withJson($__response_data, $__response_status_code);
            }

            if(isset($req_body['id']) && empty($person_id))
            {
                $__response_status_code = 400;
                $__response_data = array(
                    'error' => array(
                        'errorType' => 'invalid_request',
                        'fieldName' => 'id',
                        'message' => 'Missing id parameter value.'
                    ),
                    'success' => false
                );

                return $res->withJson($__response_data, $__response_status_code);
            }

            if(isset($req_body['id']) && !empty($person_id))
            {
                $stmt = $db_cdpmkt->prepare('EXEC _Person @type = ?, @person_id = ?, @status = ?');

                $stmt->bindValue(1, 'Select');
                $stmt->bindValue(2, $person_id);
                $stmt->bindValue(3, 'A');

                $stmt->execute();
                
                if(count($stmt->fetchAll()) == 0)
                {
                    $__response_status_code = 400;
                    $__response_data = array(
                        'error' => array(
                            'errorType' => 'invalid_request',
                            'fieldName' => 'id',
                            'message' => 'id invalid.'
                        ),
                        'success' => false
                    );

                    return $res->withJson($__response_data, $__response_status_code);
                }
            }

            if(!isset($req_body['id']))
            {
                if(isset($req_body['email']) && !empty($email))
                {
                    $stmt = $db_cdpmkt->prepare('EXEC _Person @type = ?, @email = ?, @verify_email = ?, @status = ?');
    
                    $stmt->bindValue(1, 'Select');
                    $stmt->bindValue(2, $email);
                    $stmt->bindValue(3, 'Y');
                    $stmt->bindValue(4, 'A');
    
                    $stmt->execute();
    
                    $_person = $stmt->fetch();
    
                    if(isset($_person['personId']) && $_person['personId'] != '')
                    {
                        $__response_status_code = 400;
                        $__response_data = array(
                            'error' => array(
                                'errorType' => 'invalid_request',
                                'fieldName' => 'email',
                                'message' => 'email already used.'
                            ),
                            'success' => false
                        );

                        return $res->withJson($__response_data, $__response_status_code);
                    }
                }
                
                if(isset($req_body['mobile_no']) && !empty($mobile_no))
                {
                    $stmt = $db_cdpmkt->prepare('EXEC _Person @type = ?, @mobile_no = ?, @verify_phone = ?, @status = ?');
    
                    $stmt->bindValue(1, 'Select');
                    $stmt->bindValue(2, $mobile_no);
                    $stmt->bindValue(3, 'Y');
                    $stmt->bindValue(4, 'A');
    
                    $stmt->execute();
    
                    $_person = $stmt->fetch();
    
                    if(isset($_person['personId']) && $_person['personId'] != '')
                    {
                        $__response_status_code = 400;
                        $__response_data = array(
                            'error' => array(
                                'errorType' => 'invalid_request',
                                'fieldName' => 'mobile_no',
                                'message' => 'mobile_no already used.'
                            ),
                            'success' => false
                        );

                        return $res->withJson($__response_data, $__response_status_code);
                    }
                }

                if(isset($req_body['id_card_no']) && !empty($id_card_no))
                {
                    $stmt = $db_cdpmkt->prepare('EXEC _Person @type = ?, @id_card = ?, @verify_idcard = ?, @status = ?');
    
                    $stmt->bindValue(1, 'Select');
                    $stmt->bindValue(2, $id_card_no);
                    $stmt->bindValue(3, 'Y');
                    $stmt->bindValue(4, 'A');
    
                    $stmt->execute();
    
                    $_person = $stmt->fetch();
    
                    if(isset($_person['personId']) && $_person['personId'] != '')
                    {
                        $__response_status_code = 400;
                        $__response_data = array(
                            'error' => array(
                                'errorType' => 'invalid_request',
                                'fieldName' => 'id_card_no',
                                'message' => 'id_card_no already used.'
                            ),
                            'success' => false
                        );

                        return $res->withJson($__response_data, $__response_status_code);
                    }
                }
            }

            if(empty($id_card_no) && empty($passport_no))
            {
                $__response_status_code = 400;
                $__response_data = array(
                    'error' => array(
                        'errorType' => 'invalid_request',
                        'fieldName' => 'id_card_no, passport_no',
                        'message' => 'Missing parameters: id_card_no, passport_no'
                    ),
                    'success' => false
                );

                return $res->withJson($__response_data, $__response_status_code);
            }

            if(isset($req_body['id_card_no']) && empty($id_card_no))
            {
                $__response_status_code = 400;
                $__response_data = array(
                    'error' => array(
                        'errorType' => 'invalid_request',
                        'fieldName' => 'id_card_no',
                        'message' => 'Missing id_card_no parameter value.'
                    ),
                    'success' => false
                );

                return $res->withJson($__response_data, $__response_status_code);
            }

            if(isset($req_body['passport_no']) && empty($passport_no))
            {
                $__response_status_code = 400;
                $__response_data = array(
                    'error' => array(
                        'errorType' => 'invalid_request',
                        'fieldName' => 'passport_no',
                        'message' => 'Missing passport_no parameter value.'
                    ),
                    'success' => false
                );

                return $res->withJson($__response_data, $__response_status_code);
            }
            
            if(isset($req_body['verify_email']) && empty($verify_email))
            {
                $__response_status_code = 400;
                $__response_data = array(
                    'error' => array(
                        'errorType' => 'invalid_request',
                        'fieldName' => 'verify_email',
                        'message' => 'Missing verify_email parameter value.'
                    ),
                    'success' => false
                );

                return $res->withJson($__response_data, $__response_status_code);
            }

            if(isset($req_body['verify_phone']) && empty($verify_phone))
            {
                $__response_status_code = 400;
                $__response_data = array(
                    'error' => array(
                        'errorType' => 'invalid_request',
                        'fieldName' => 'verify_phone',
                        'message' => 'Missing verify_phone parameter value.'
                    ),
                    'success' => false
                );

                return $res->withJson($__response_data, $__response_status_code);
            }

            $stmt = $db_cdpmkt->prepare('EXEC _Person @type = ?, @mobile_no = ?, @status = ?');

            $stmt = $this->bindValue($stmt, array(
                'type' => 'Select',
                'mobile_no' => $mobile_no,
                'status' => 'A'
            ));

            $stmt->execute();

            $__person_delete = $stmt->fetchAll();

            foreach($__person_delete as $__p)
            {
                $stmt = $db_cdpmkt->prepare('EXEC _Person @type = ?, @person_id = ?, @person_status = ?');

                $stmt = $this->bindValue($stmt, array(
                    'type' => 'Update',
                    'person_id' => $__p['personId'],
                    'person_status' => 'D'
                ));
    
                $stmt->execute();

                $stmt = $db_cdpmkt->prepare('EXEC _Person @type = ?, @person_id = ?, @transaction_type = ?, @ti_id_current = ?, @transaction_reason = ?, @chanel = ?, @transaction_status = ?, @createdatetime = ?, @createby = ?, @updatedatetime = ?, @lastupdateby = ?');

                $stmt = $this->bindValue($stmt, array(
                    'type' => 'Update',
                    'person_id' => $__p['personId'],
                    'transaction_type' => 'Deleted',
                    'ti_id_current' => $old_tier_id,
                    'transaction_reason' => NULL,
                    'chanel' => NULL,
                    'transaction_status' => 'A',
                    'createdatetime' => $datetime_now,
                    'createby' => $user_id,
                    'updatedatetime' => $datetime_now,
                    'lastupdateby' => $user_id
                ));
    
                $stmt->execute();
            }

            if($member_number_ref != NULL)
            {
                $stmt = $db_cdpmkt->prepare('EXEC _Person @type = ?, @person_id = ?, @status = ?');

                $stmt->bindValue(1, 'Select');
                $stmt->bindValue(2, $person_id);
                $stmt->bindValue(3, 'A');

                $stmt->execute();

                $__person = $stmt->fetch();

                $point = NULL;
                $point_bonus = NULL;
                $point_accumulate = NULL;
                $point_spending = NULL;
                $point_balance = NULL;

                $chanel = (isset($__person['source']) && $__person['source'] != '' ? $__person['source'] : $chanel);
            }

            if($person_id != NULL)
            {
                $stmt = $db_cdpmkt->prepare('EXEC _Person @type = ?, @person_id = ?, @ti_id = ?, @memb_type = ?, @register_status = ?, @memberNoRef = ?, @firstname = ?, @lastname = ?, @gender = ?, @birthdate = ?, @age = ?, @id_card = ?, @passport = ?, @email = ?, @password = ?, @mobile_no = ?, @nation_code = ?, @person_point = ?, @person_point_bonus = ?, @person_point_accumulate = ?, @person_point_spending = ?, @person_point_balance = ?, @education_id = ?, @occupation = ?, @career_level = ?, @career = ?, @salary = ?, @number_of_child = ?, @number_of_family = ?, @religion = ?, @chanel = ?, @device = ?, @preferred_channel = ?, @memberexpire = ?, @not_phone = ?, @not_idcard = ?, @verify_phone = ?, @verify_email = ?, @verify_idcard = ?, @is_member = ?, @is_consent = ?, @remark = ?, @person_status = ?, @person_member_status = ?, @registerdatetime = ?, @createdatetime = ?, @createby = ?, @updatedatetime = ?, @lastupdateby = ?');
    
                $stmt = $this->bindValue($stmt, array(
                    'type' => 'Update',
                    'person_id' => $person_id,
                    'ti_id' => $tier_id,
                    'memb_type' => $register_type,
                    'register_status' => $register_status,
                    'memberNoRef' => $member_number_ref,
                    'firstname' => $firstname,
                    'lastname' => $lastname,
                    'gender' => $gender,
                    'birthdate' => $date_of_birth,
                    'age' => NULL,
                    'id_card' => $id_card_no,
                    'passport' => $passport_no,
                    'email' => $email,
                    'password' => $password,
                    'mobile_no' => $mobile_no,
                    'nation_code' => $nationality,
                    'person_point' => $point,
                    'person_point_bonus' => $point_bonus,
                    'person_point_accumulate' => $point_accumulate,
                    'person_point_spending' => $point_spending,
                    'person_point_balance' => $point_balance,
                    'education_id' => $education_id,
                    'occupation' => $occupation,
                    'career_level' => $career_level,
                    'career' => $career,
                    'salary' => $salary,
                    'number_of_child' => $number_of_child,
                    'number_of_family' => $number_of_family,
                    'religion' => $religion,
                    'chanel' => $chanel,
                    'device' => $device,
                    'preferred_channel' => $subscribe,
                    'memberexpire' => NULL,
                    'not_phone' => $not_phone,
                    'not_idcard' => $not_idcard,
                    'verify_phone' => $verify_phone,
                    'verify_email' => $verify_email,
                    'verify_idcard' => $verify_phone,
                    'is_member' => $is_member,
                    'is_consent' => $consent,
                    'remark' => $remark,
                    'person_status' => 'A',
                    'person_member_status' => 'A',
                    'registerdatetime' => $datetime_now,
                    'createdatetime' => $datetime_now,
                    'createby' => $user_id,
                    'updatedatetime' => $datetime_now,
                    'lastupdateby' => $user_id,
                ));

                $stmt->execute();

                $person = $stmt->fetch();

                $person_id = $person['last_insert_id'];
                $tier_id = $person['tier_id'];
                $old_tier_id = $person['old_tier_id'];
            }
            else
            {
                $stmt = $db_cdpmkt->prepare('EXEC _Person @type = ?, @ti_id = ?, @memb_type = ?, @register_status = ?, @memberNoRef = ?, @firstname = ?, @lastname = ?, @gender = ?, @birthdate = ?, @age = ?, @id_card = ?, @passport = ?, @email = ?, @password = ?, @mobile_no = ?, @nation_code = ?, @person_point = ?, @person_point_bonus = ?, @person_point_accumulate = ?, @person_point_spending = ?, @person_point_balance = ?, @education_id = ?, @occupation = ?, @career_level = ?, @career = ?, @salary = ?, @number_of_child = ?, @number_of_family = ?, @religion = ?, @chanel = ?, @device = ?, @preferred_channel = ?, @memberexpire = ?, @not_phone = ?, @not_idcard = ?, @verify_phone = ?, @verify_email = ?, @verify_idcard = ?, @is_member = ?, @is_consent = ?, @remark = ?, @person_status = ?, @person_member_status = ?, @registerdatetime = ?, @createdatetime = ?, @createby = ?, @updatedatetime = ?, @lastupdateby = ?');
        
                $stmt = $this->bindValue($stmt, array(
                    'type' => 'Insert',
                    'ti_id' => $tier_id,
                    'memb_type' => $register_type,
                    'register_status' => $register_status,
                    'memberNoRef' => $member_number_ref,
                    'firstname' => $firstname,
                    'lastname' => $lastname,
                    'gender' => $gender,
                    'birthdate' => $date_of_birth,
                    'age' => NULL,
                    'id_card' => $id_card_no,
                    'passport' => $passport_no,
                    'email' => $email,
                    'password' => $password,
                    'mobile_no' => $mobile_no,
                    'nation_code' => $nationality,
                    'person_point' => $point,
                    'person_point_bonus' => $point_bonus,
                    'person_point_accumulate' => $point_accumulate,
                    'person_point_spending' => $point_spending,
                    'person_point_balance' => $point_balance,
                    'education_id' => $education_id,
                    'occupation' => $occupation,
                    'career_level' => $career_level,
                    'career' => $career,
                    'salary' => $salary,
                    'number_of_child' => $number_of_child,
                    'number_of_family' => $number_of_family,
                    'religion' => $religion,
                    'chanel' => $chanel,
                    'device' => $device,
                    'preferred_channel' => $subscribe,
                    'memberexpire' => NULL,
                    'not_phone' => $not_phone,
                    'not_idcard' => $not_idcard,
                    'verify_phone' => $verify_phone,
                    'verify_email' => $verify_email,
                    'verify_idcard' => $verify_phone,
                    'is_member' => 'Y',
                    'is_consent' => $consent,
                    'remark' => $remark,
                    'person_status' => 'A',
                    'person_member_status' => 'A',
                    'registerdatetime' => $datetime_now,
                    'createdatetime' => $datetime_now,
                    'createby' => $user_id,
                    'updatedatetime' => $datetime_now,
                    'lastupdateby' => $user_id
                ));

                $stmt->execute();

                $person = $stmt->fetch();

                $person_id = $person['last_insert_id'];
                $tier_id = $person['tier_id'];
                $old_tier_id = $person['old_tier_id'];
            }

            if($person_id != NULL)
            {
                $stmt = $db_cdpmkt->prepare('EXEC _Person @type = ?, @person_id = ?, @transaction_type = ?, @ti_id_current = ?, @ti_id = ?, @transaction_reason = ?, @chanel = ?, @transaction_status = ?, @createdatetime = ?, @updatedatetime = ?');

                $stmt->bindValue(1, 'Insert Tier History');
                $stmt->bindValue(2, $person_id);
                $stmt->bindValue(3, 'Register');
                $stmt->bindValue(4, $old_tier_id);
                $stmt->bindValue(5, $tier_id);
                $stmt->bindValue(6, $register_status);
                $stmt->bindValue(7, $chanel);
                $stmt->bindValue(8, 'A');
                $stmt->bindValue(9, $datetime_now);
                $stmt->bindValue(10, $datetime_now);

                $stmt->execute();

                $stmt = $db_cdpmkt->prepare('EXEC _Person_Session @type = ?, @person_id = ?, @session_id = ?, @status = ?');

                $stmt->bindValue(1, 'Select');
                $stmt->bindValue(2, $person_id);
                $stmt->bindValue(3, $session_id);
                $stmt->bindValue(4, 'Active');

                $stmt->execute();
                
                if(count($stmt->fetchAll()) == 0)
                {
                    $stmt = $db_cdpmkt->prepare('EXEC _Person_Session @type = ?, @person_id = ?, @session_id = ?, @status = ?, @createdatetime = ?, @updatedatetime = ?');

                    $stmt->bindValue(1, 'Insert');
                    $stmt->bindValue(2, $person_id);
                    $stmt->bindValue(3, $session_id);
                    $stmt->bindValue(4, 'Active');
                    $stmt->bindValue(5, $datetime_now);
                    $stmt->bindValue(6, $datetime_now);
    
                    $stmt->execute();
                }

                if($line_user_id != NULL)
                {
                    $stmt = $db_cdpmkt->prepare('EXEC _Person_Social @type = ?, @person_id = ?, @social_type = ?, @status = ?');

                    $stmt = $this->bindValue($stmt, array(
                        'type' => 'Select',
                        'person_id' => $person_id,
                        'social_type' => 'Line',
                        'status' => 'A'
                    ));

                    $stmt->execute();

                    if(count($stmt->fetchAll()) == 0)
                    {
                        $stmt = $db_cdpmkt->prepare('EXEC _Person_Social @type = ?, @person_id = ?, @social_type = ?, @social_value = ?, @social_name = ?, @social_picture_url = ?, @social_status_message = ?, @status = ?, @createdatetime = ?, @creaetby = ?, @updatedatetime = ?, @updateby = ?');

                        $stmt = $this->bindValue($stmt, array(
                            'type' => 'Insert',
                            'person_id' => $person_id,
                            'social_type' => 'Line',
                            'social_value' => $line_user_id,
                            'social_name' => $line_display_name,
                            'social_picture_url' => $line_picture_url,
                            'social_status_message' => $line_status_message,
                            'status' => 'A',
                            'createdatetime' => $datetime_now,
                            'creaetby' => $user_id,
                            'updatedatetime' => $datetime_now,
                            'updateby' => $user_id
                        ));

                        $stmt->execute();
                    }
                    else
                    {
                        $stmt = $db_cdpmkt->prepare('EXEC _Person_Social @type = ?, @person_id = ?, @social_type = ?, @social_value = ?, @social_name = ?, @social_picture_url = ?, @social_status_message = ?, @status = ?, @updatedatetime = ?, @updateby = ?');

                        $stmt = $this->bindValue($stmt, array(
                            'type' => 'Update',
                            'person_id' => $person_id,
                            'social_type' => 'Line',
                            'social_value' => $line_user_id,
                            'social_name' => $line_display_name,
                            'social_picture_url' => $line_picture_url,
                            'social_status_message' => $line_status_message,
                            'status' => 'A',
                            'updatedatetime' => $datetime_now,
                            'updateby' => $user_id
                        ));
        
                        $stmt->execute();
                    }
                }

                $__response_status_code = 200;
                $__response_data = array(
                    'response_body' => array(
                        'person_id' => $person_id,
                        'message' => 'Register success.'
                    ),
                    'success' => true
                );
            }
            else
            {
                $__response_status_code = 500;
                $__response_data = array(
                    'error' => array(
                        'errorType' => 'internal_error',
                        'message' => 'Register success., Person not found.'
                    ),
                    'success' => false
                );
            }

            $stmt = $db_cdpmkt->prepare('EXEC _Activity @type = ?, @register_new_system = ?, @activity_datetime = ?, @campaign_status = ?, @subcampaign_status = ?, @activity_status = ?, @campaign_approve = ?, @subcampaign_approve = ?, @activity_approve = ?');

            $stmt = $this->bindValue($stmt, array(
                'type' => 'Get',
                'register_new_system' => 'Y',
                'activity_datetime' => $datetime_now,
                'campaign_status' => 'A',
                'subcampaign_status' => 'A',
                'activity_status' => 'A',
                'campaign_approve' => 'A',
                'subcampaign_approve' => 'A',
                'activity_approve' => 'A'
            ));

            $stmt->execute();

            $__activity_list = $stmt->fetchAll();

            foreach($__activity_list as $_a)
            {
                $regis_new_system_lower = strtolower($_a['regis_new_system']);
                $chanel_lower = strtolower($chanel);

                if($regis_new_system_lower == $chanel_lower || $regis_new_system_lower = 'all')
                {
                    if($_a['is_only_member'] == 'Y')
                    {
                        $stmt = $db_cdpmkt->prepare('EXEC _Activity @type = ?, @tier_id = ?, @activity_id = ?, @activity_usable = ?, @activity_status = ?');

                        $stmt->bindValue(1, 'Get Member');
                        $stmt->bindValue(2, $tier_id);
                        $stmt->bindValue(3, $_a['activityId']);
                        $stmt->bindValue(4, 'Y');
                        $stmt->bindValue(5, 'A');

                        $stmt->execute();

                        $__activity_member_list = $stmt->fetch();

                        if(isset($__activity_member_list['activity_id']) && $__activity_member_list['activity_id'] == '')
                        {
                            continue;
                        }
                    }

                    if($_a['is_lineonly'] == 'Y')
                    {
                        $stmt = $db_cdpmkt->prepare('EXEC _Activity @type = ?, @campaign_id = ?, @sub_campaign_id = ?, @activity_id = ?, @tier_id = ?, @person_id = ?, @activity_status = ?, @transaction_datetime = ?, @transaction_createby = ?');

                        $stmt->bindValue(1, 'Insert Personal');
                        $stmt->bindValue(2, $_a['campId']);
                        $stmt->bindValue(3, $_a['subcampId']);
                        $stmt->bindValue(4, $_a['activityId']);
                        $stmt->bindValue(5, $tier_id);
                        $stmt->bindValue(6, $person_id);
                        $stmt->bindValue(7, 'A');
                        $stmt->bindValue(8, $datetime_now);
                        $stmt->bindValue(9, $user_id);
                        
                        $stmt->execute();
                    }

                    if($_a['insertData'] == 'Y')
                    {
                        $history_ref_type_id = 0;

                        if($_a['activityType'] == 'Form')
                        {
                            $history_ref_type_id = 2;
                        }
                        else if($_a['activityType'] == 'Checkin-Checkout')
                        {
                            $history_ref_type_id = 13;
                        }
                        else if($_a['activityType'] == 'Lucky Draw Random' || $_a['activityType'] == 'LuckyDrawRandom')
                        {
                            $history_ref_type_id = 15;
                        }
                        else if($_a['activityType'] == 'Promotion')
                        {
                            $history_ref_type_id = 3;
                        }

                        $stmt = $db_cdpmkt->prepare('EXEC _Person_History @type = ?, @person_id = ?, @reference_type_id = ?, @reference_id = ?, @history_status = ?, @history_createdatetime = ?, @person_status = ?, @history_createby = ?');

                        $stmt->bindValue(1, 'Insert');
                        $stmt->bindValue(2, $person_id);
                        $stmt->bindValue(3, $history_ref_type_id);
                        $stmt->bindValue(4, $_a['activityId']);
                        $stmt->bindValue(5, 'A');
                        $stmt->bindValue(6, $datetime_now);
                        $stmt->bindValue(7, $register_status);
                        $stmt->bindValue(8, $user_id);

                        $stmt->execute();

                        $history_id = $stmt->fetch()['insert_id'];

                        $stmt = $db_cdpmkt->prepare('EXEC _Activity_Limit @type = ?, @activity_id = ?, @limit_status = ?');

                        $stmt = $this->bindValue($stmt, array(
                            'type' => 'Get',
                            'activity_id' => $_a['activityId'],
                            'limit_status' => 'A'
                        ));

                        $stmt->execute();

                        $__activity_limit = $stmt->fetchAll();

                        $limit_check_temp = true;
                        $limit_check = true;

                        $customer_participate = -1;
                        $customer_badge = -1;
                        $customer_point = -1;
                        $activity_participate = -1;
                        $activity_badge = -1;
                        $activity_point = -1;

                        foreach($__activity_limit as $limit)
                        {
                            $transaction_start_datetime = NULL;
                            $transaction_end_datetime = NULL;

                            if($limit['limit_period'] == 'Day')
                            {
                                $transaction_start_datetime = date('Y-m-d', strtotime($datetime_now)) . ' 00:00:00';
                                $transaction_end_datetime = date('Y-m-d', strtotime($datetime_now)) . ' 23:59:59';
                            }
                            else if($limit['limit_period'] == 'Month')
                            {
                                $transaction_start_datetime = date('Y-m-d', strtotime('first day of this month', strtotime($datetime_now))) . ' 00:00:00';
                                $transaction_end_datetime = date('Y-m-d', strtotime('last day of this month', strtotime($datetime_now))) . ' 23:59:59';
                            }
                            else if($limit['limit_period'] == 'Period')
                            {
                                $transaction_start_datetime = $_a['startDisplay'];
                                $transaction_end_datetime = $_a['endDisplay'];
                            }

                            if($limit['limit_type'] == 'Maximum')
                            {
                                $is_person = true;

                                if($limit['limit_level'] == 'Activity')
                                {
                                    $is_person = false;
                                }
                                else if($limit['limit_level'] == 'Customer')
                                {
                                    $is_person = true;
                                }

                                if($limit['limit_variable'] == 'Badge')
                                {
                                    $stmt = $db_cdpmkt->prepare('EXEC _Activity_Limit @type = ?, @activity_id = ?, @person_id = ?, @condition_status = ?, @transaction_start_datetime = ?, @transaction_end_datetime = ?');

                                    $stmt = $this->bindValue($stmt, array(
                                        'type' => 'Badge',
                                        'activity_id' => $_a['activityId'],
                                        'person_id' => ($is_person ? $person_id : NULL),
                                        'condition_status' => 'A',
                                        'transaction_start_datetime' => $transaction_start_datetime,
                                        'transaction_end_datetime' => $transaction_end_datetime
                                    ));
        
                                    $stmt->execute();

                                    $badge = $stmt->fetch();

                                    if($limit['limit_level'] == 'Activity')
                                    {
                                        $activity_badge = intval($limit['limit_value']) - intval($badge['total_badge']);

                                        if($activity_badge < 0)
                                        {
                                            $activity_badge = 0;
                                        }
                                    }
                                    else if($limit['limit_level'] == 'Customer')
                                    {
                                        $customer_badge = intval($limit['limit_value']) - intval($badge['total_badge']);

                                        if($customer_badge < 0)
                                        {
                                            $customer_badge = 0;
                                        }
                                    }

                                    $limit_check_temp = true;
                                }
                                else if($limit['limit_variable'] == 'Participate')
                                {
                                    $st_type = NULL;
                                    $activity_type = NULL;

                                    if($_a['activityType'] == 'Form')
                                    {
                                        $st_type = 'Form Participate';
                                    }
                                    else if($_a['activityType'] == 'Checkin-Checkout')
                                    {
                                        $st_type = 'Checkin-Checkout Participate';
                                    }
                                    else if($_a['activityType'] == 'Lucky Draw Random' || $_a['activityType'] == 'LuckyDrawRandom')
                                    {
                                        $st_type = 'Lucky Draw Participate';
                                    }
                                    else if($_a['activityType'] == 'Promotion')
                                    {
                                        $st_type = 'Promotion Participate';
                                    }

                                    $stmt = $db_cdpmkt->prepare('EXEC _Activity_Limit @type = ?, @activity_id = ?, @person_id = ?, @activity_type = ?, @condition_status = ?, @transaction_start_datetime = ?, @transaction_end_datetime = ?');

                                    $stmt = $this->bindValue($stmt, array(
                                        'type' => $st_type,
                                        'activity_id' => $_a['activityId'],
                                        'person_id' => $person_id,
                                        'activity_type' => $activity_type,
                                        'condition_status' => 'A',
                                        'transaction_start_datetime' => $transaction_start_datetime,
                                        'transaction_end_datetime' => $transaction_end_datetime
                                    ));
        
                                    $stmt->execute();

                                    $participate = $stmt->fetch();

                                    if($limit['limit_level'] == 'Activity')
                                    {
                                        $activity_participate = intval($limit['limit_value']) - intval($participate['total_participate']);
                                    }
                                    else if($limit['limit_level'] == 'Customer')
                                    {
                                        $customer_participate = intval($limit['limit_value']) - intval($participate['total_participate']);
                                    }

                                    if($_a['activityType'] == 'Form')
                                    {
                                        $limit_check_temp = true;
                                    }
                                    else
                                    {
                                        if($limit['limit_level'] == 'Activity' && $activity_participate <= 0)
                                        {
                                            $limit_check_temp = false;
                                        }
                                        else
                                        {
                                            $limit_check_temp = true;
                                        }

                                        if($limit['limit_level'] == 'Customer' && $customer_participate <= 0)
                                        {
                                            $limit_check_temp = false;
                                        }
                                        else
                                        {
                                            $limit_check_temp = true;
                                        }
                                    }
                                }
                                else if($limit['limit_variable'] == 'Point')
                                {
                                    $stmt = $db_cdpmkt->prepare('EXEC _Activity_Limit @type = ?, @activity_id = ?, @person_id = ?, @activity_type = ?, @point_type = ?, @condition_status = ?, @transaction_start_datetime = ?, @transaction_end_datetime = ?');

                                    $stmt = $this->bindValue($stmt, array(
                                        'type' => 'Point',
                                        'activity_id' => $_a['activityId'],
                                        'person_id' => ($is_person ? $person_id : NULL),
                                        'activity_type' => $history_ref_type_id,
                                        'point_type' => 'Earn',
                                        'condition_status' => 'A',
                                        'transaction_start_datetime' => $transaction_start_datetime,
                                        'transaction_end_datetime' => $transaction_end_datetime
                                    ));

                                    $stmt->execute();

                                    $point = $stmt->fetch();

                                    if($limit['limit_level'] == 'Activity')
                                    {
                                        $activity_point = intval($limit['limit_value']) - intval($point['total_point']);

                                        if($activity_point < 0)
                                        {
                                            $activity_point = 0;
                                        }
                                    }
                                    else if($limit['limit_level'] == 'Customer')
                                    {
                                        $customer_point = intval($limit['limit_value']) - intval($point['total_point']);

                                        if($customer_point < 0)
                                        {
                                            $customer_point = 0;
                                        }
                                    }

                                    $limit_check_temp = true;
                                }
                            }

                            $limit_check = ($limit_check && $limit_check_temp);

                            if(!$limit_check)
                            {
                                continue 2;
                            }
                        }

                        if($_a['activityType'] == 'Form')
                        {
                            $stmt = $db_cdpmkt->prepare('EXEC _Activity @type = ?, @activity_id = ?, @activity_status = ?');

                            $stmt->bindValue(1, 'Get Form');
                            $stmt->bindValue(2, $_a['activityId']);
                            $stmt->bindValue(3, 'Y');

                            $stmt->execute();

                            $__activity_form_list = $stmt->fetchAll();

                            foreach($__activity_form_list as $_af)
                            {
                                $stmt = $db_cdpmkt->prepare('EXEC _Activity @type = ?, @campaign_id = ?, @sub_campaign_id = ?, @activity_id = ?, @form_id = ?, @history_id = ?, @tier_id = ?, @person_id = ?, @privilege_id = ?, @privilege_code = ?, @question_number = ?, @question = ?, @answer = ?, @activity_status = ?, @activity_datetime = ?, @person_status = ?');

                                $question = $_af['field_mapping'];
                                $answer = '';

                                if($_af['table_mapping'] == 'person' && $_af['field_mapping'] == 'firstname' && $firstname != NULL)
                                {
                                    $answer = $firstname;
                                }
                                else if($_af['table_mapping'] == 'person' && $_af['field_mapping'] == 'lastname' && $lastname != NULL)
                                {
                                    $answer = $lastname;
                                }
                                else if($_af['table_mapping'] == 'person' && $_af['field_mapping'] == 'idCardNo' && $id_card_no != NULL)
                                {
                                    $answer = $id_card_no;
                                }
                                else if($_af['table_mapping'] == 'person' && $_af['field_mapping'] == 'mobileNo' && $mobile_no != NULL)
                                {
                                    $answer = $mobile_no;
                                }
                                else if($_af['table_mapping'] == 'person' && $_af['field_mapping'] == 'birthdate' && $date_of_birth != NULL)
                                {
                                    $answer = $date_of_birth;
                                }
                                else if($_af['table_mapping'] == 'person' && $_af['field_mapping'] == 'email' && $email != NULL)
                                {
                                    $answer = $email;
                                }
                                else if($_af['table_mapping'] == 'person' && $_af['field_mapping'] == 'gender' && $gender != NULL)
                                {
                                    $answer = $gender;
                                }

                                $stmt->bindValue(1, 'Insert Form');
                                $stmt->bindValue(2, $_af['campaign_id']);
                                $stmt->bindValue(3, $_af['sub_campaign_id']);
                                $stmt->bindValue(4, $_af['activity_id']);
                                $stmt->bindValue(5, $_af['form_id']);
                                $stmt->bindValue(6, $history_id);
                                $stmt->bindValue(7, $tier_id);
                                $stmt->bindValue(8, $person_id);
                                $stmt->bindValue(9, NULL);
                                $stmt->bindValue(10, NULL);
                                $stmt->bindValue(11, $_af['sort']);
                                $stmt->bindValue(12, $question);
                                $stmt->bindValue(13, $answer);
                                $stmt->bindValue(14, 'Complete');
                                $stmt->bindValue(15, $datetime_now);
                                $stmt->bindValue(16, $register_status);
    
                                $stmt->execute();
                            }
                        }
                        else if($_a['activityType'] == 'Checkin-Checkout')
                        {
                            $stmt = $db_cdpmkt->prepare('EXEC _Activity @type = ?, @campaign_id = ?, @sub_campaign_id = ?, @activity_id = ?, @tier_id = ?, @person_id = ?, @history_id = ?, @activity_type = ?, @mobile_number = ?, @activity_status = ?, @transaction_datetime = ?');

                            $stmt->bindValue(1, 'Insert Check in Check out');
                            $stmt->bindValue(2, $_a['campId']);
                            $stmt->bindValue(3, $_a['subcampId']);
                            $stmt->bindValue(4, $_a['activityId']);
                            $stmt->bindValue(5, $tier_id);
                            $stmt->bindValue(6, $person_id);
                            $stmt->bindValue(7, $history_id);
                            $stmt->bindValue(8, 'check-in');
                            $stmt->bindValue(9, $mobile_no);
                            $stmt->bindValue(10, 'A');
                            $stmt->bindValue(11, $datetime_now);

                            $stmt->execute();
                        }
                        else if($_a['activityType'] == 'Lucky Draw Random' || $_a['activityType'] == 'LuckyDrawRandom')
                        {
                            $stmt = $db_cdpmkt->prepare('EXEC _Activity @type = ?, @activity_id = ?, @activity_status = ?');

                            $stmt->bindValue(1, 'Get Form');
                            $stmt->bindValue(2, $_a['activityId']);
                            $stmt->bindValue(3, 'A');

                            $stmt->execute();

                            $__luckdraw_item = $stmt->fetch();

                            $stmt = $db_cdpmkt->prepare('EXEC _Activity @type = ?, @campaign_id = ?, @sub_campaign_id = ?, @activity_id = ?, @tier_id = ?, @person_id = ?, @history_id = ?, @item_id = ?, @activity_datetime = ?, @reward_status = ?, @activity_status = ?');

                            $stmt->bindValue(1, 'Insert Luckydraw');
                            $stmt->bindValue(2, $_a['campId']);
                            $stmt->bindValue(3, $_a['subcampId']);
                            $stmt->bindValue(4, $_a['activityId']);
                            $stmt->bindValue(5, $tier_id);
                            $stmt->bindValue(6, $person_id);
                            $stmt->bindValue(7, $history_id);
                            $stmt->bindValue(8, $__luckdraw_item['item_id']);
                            $stmt->bindValue(9, $datetime_now);
                            $stmt->bindValue(10, 'Used');
                            $stmt->bindValue(11, 'A');
    
                            $stmt->execute();
                        }
                        else if($_a['activityType'] == 'Promotion')
                        {
                            $promotion_code_id = '';
                            $promotion_code_type = 'Auto';
                            $promotion_code = '';
                            $promotion_code_expire = date('Y-m-d H:i:s', strtotime($datetime_now. ' + 30 minutes'));

                            if($_a['codeAuto'] == 'Auto' && $_a['limit'] == -1)
                            {
                                do
                                {
                                    $promotion_code = $_a['activityId'] . '-' . $this->generateRandomString(6);

                                    $stmt = $db_cdpmkt->prepare('EXEC _Activity @type = ?, @activity_id = ?, @promotion_code = ?');

                                    $stmt->bindValue(1, 'Check Promotion Code');
                                    $stmt->bindValue(2, $_a['activityId']); 
                                    $stmt->bindValue(3, $promotion_code);

                                    $stmt->execute();

                                    $promotion_code_id = $stmt->fetch()['promotion_code_id'] ?? '';
                                } while($promotion_code_id != '');

                                $stmt = $db_cdpmkt->prepare('EXEC _Activity @type = ?, @campaign_id = ?, @sub_campaign_id = ?, @activity_id = ?, @history_id = ?, @tier_id = ?, @promotion_code_type = ?, @promotion_code = ?, @activity_status = ?, @promotion_code_expire = ?, @promotion_code_qr_code = ?, @use_status = ?, @person_id = ?, @transaction_datetime = ?, @person_status = ?, @activity_references = ?, @transaction_createby = ?');
    
                                $stmt->bindValue(1, 'Insert Promotion');
                                $stmt->bindValue(2, $_a['campId']);
                                $stmt->bindValue(3, $_a['subcampId']);
                                $stmt->bindValue(4, $_a['activityId']);
                                $stmt->bindValue(5, $history_id);
                                $stmt->bindValue(6, $tier_id);
                                $stmt->bindValue(7, $promotion_code_type);
                                $stmt->bindValue(8, $promotion_code);
                                $stmt->bindValue(9, 'A');
                                $stmt->bindValue(10, $promotion_code_expire);
                                $stmt->bindValue(11, NULL);
                                $stmt->bindValue(12, 'Y');
                                $stmt->bindValue(13, $person_id);
                                $stmt->bindValue(14, $datetime_now);
                                $stmt->bindValue(15, $register_status);
                                $stmt->bindValue(16, 'r=' . $chanel);
                                $stmt->bindValue(17, $user_id);
        
                                $stmt->execute();

                                $promotion_code_id = $stmt->fetch()['last_insert_id'];
                            }
                            else if($_a['codeAuto'] == 'Manual' && $_a['limit'] == -1)
                            {
                                $promotion_code_type = 'Manual';
                                $promotion_code = $_a['genCode'];

                                $stmt = $db_cdpmkt->prepare('EXEC _Activity @type = ?, @campaign_id = ?, @sub_campaign_id = ?, @activity_id = ?, @history_id = ?, @tier_id = ?, @promotion_code_type = ?, @promotion_code = ?, @activity_status = ?, @promotion_code_expire = ?, @promotion_code_qr_code = ?, @use_status = ?, @person_id = ?, @transaction_datetime = ?, @person_status = ?, @activity_references = ?, @transaction_createby = ?');
    
                                $stmt->bindValue(1, 'Insert Promotion');
                                $stmt->bindValue(2, $_a['campId']);
                                $stmt->bindValue(3, $_a['subcampId']);
                                $stmt->bindValue(4, $_a['activityId']);
                                $stmt->bindValue(5, $history_id);
                                $stmt->bindValue(6, $tier_id);
                                $stmt->bindValue(7, $promotion_code_type);
                                $stmt->bindValue(8, $promotion_code);
                                $stmt->bindValue(9, 'A');
                                $stmt->bindValue(10, $promotion_code_expire);
                                $stmt->bindValue(11, NULL);
                                $stmt->bindValue(12, 'Y');
                                $stmt->bindValue(13, $person_id);
                                $stmt->bindValue(14, $datetime_now);
                                $stmt->bindValue(15, $register_status);
                                $stmt->bindValue(16, 'r=' . $chanel);
                                $stmt->bindValue(17, $user_id);
        
                                $stmt->execute();

                                $promotion_code_id = $stmt->fetch()['last_insert_id'];
                            }
                            else
                            {
                                $stmt = $db_cdpmkt->prepare('EXEC _Activity @type = ?, @activity_id = ?, @promotion_code_type = ?, @exclude_use_status = ?');

                                $stmt->bindValue(1, 'Check Promotion Code');
                                $stmt->bindValue(2, $_a['activityId']); 
                                $stmt->bindValue(3, 'Manual');
                                $stmt->bindValue(4, 'Y');

                                $stmt->execute();

                                $promotion_code_id = $stmt->fetch();
                                $promotion_code_id = $promotion_code_id['promotion_code_id'] ?? NULL;
                                $promotion_code = $promotion_code_id['promotion_code'] ?? NULL;

                                $stmt = $db_cdpmkt->prepare('EXEC _Activity @type = ?, @promotion_code_id = ?, @person_id = ?, @use_status = ?, @transaction_datetime = ?');

                                $stmt->bindValue(1, 'Update Promotion');
                                $stmt->bindValue(2, $promotion_code_id); 
                                $stmt->bindValue(3, $person_id);
                                $stmt->bindValue(4, 'Y');
                                $stmt->bindValue(5, $datetime_now);

                                $stmt->execute();
                            }

                            $text = base64_encode(base64_encode($_a['campId']) . ';' . base64_encode($_a['subcampId']) . ';' . base64_encode($_a['activityId']) . ';' . base64_encode($promotion_code) . ';' . base64_encode('Promotion') . ';' . base64_encode($person_id) . ';' . base64_decode($promotion_code_id));
                                
                            $promotion_url = $this->url['cdpmkt'] . 'store?c=' . $text;

                            $promotion_code_qr_code = $this->genereate_qr_code($promotion_url, $this->path['cdpmkt_physical_path'], 'uploads/qrcode/' . $_a['activityCode'] . '/', date('YmdHis') . '-' . $person_id . '_' . $promotion_code . '.png');

                            $stmt = $db_cdpmkt->prepare('EXEC _Activity @type = ?, @promotion_code_id = ?, @promotion_code_qr_code = ?');

                            $stmt->bindValue(1, 'Update Promotion');
                            $stmt->bindValue(2, $promotion_code_id); 
                            $stmt->bindValue(3, $promotion_code_qr_code);

                            $stmt->execute();
                        }

                        if($_a['point'] > 0)
                        {
                            $earn_point = $_a['point'];

                            if($customer_point != -1 || $activity_point != -1)
                            {
                                if($customer_point != -1 && $earn_point > $customer_point)
                                {
                                    $earn_point = $customer_point;
                                }

                                if($activity_point != -1 && $earn_point > $activity_point)
                                {
                                    $earn_point = $customer_point;
                                }
                            }

                            if($earn_point > 0)
                            {
                                $stmt = $db_cdpmkt->prepare('EXEC _Person @type = ?, @person_id = ?');
                        
                                $stmt->bindValue(1, 'Profile');
                                $stmt->bindValue(2, $person_id);
    
                                $stmt->execute();
    
                                $person = $stmt->fetch();
    
                                $person_point_bonus = $person['person_point_bonus'] + $earn_point;
                                $person_point_accumulate = $person['person_point_accumulate'] + $earn_point;
                                $person_point_balance = $person['person_point_balance'] + $earn_point;
    
                                $stmt = $db_cdpmkt->prepare('EXEC _Person_Point @type = ?, @person_id = ?, @person_point_bonus = ?, @person_point_accumulate = ?, @person_point_balance = ?');
                                
                                $stmt->bindValue(1, 'Update Person');
                                $stmt->bindValue(2, $person_id);
                                $stmt->bindValue(3, $person_point_bonus);
                                $stmt->bindValue(4, $person_point_accumulate);
                                $stmt->bindValue(5, $person_point_balance);
    
                                $stmt->execute();
    
                                $stmt = $db_cdpmkt->prepare('EXEC _Person_Point @type = ?, @person_id = ?, @reference_type_id = ?, @reference_id = ?, @history_id = ?, @point_type = ?, @point_value = ?, @point_status = ?, @point_createdatetime = ?, @point_createby = ?, @point_updatedatetime = ?, @point_updateby = ?');
    
                                $stmt->bindValue(1, 'Insert');
                                $stmt->bindValue(2, $person_id);
                                $stmt->bindValue(3, 2);
                                $stmt->bindValue(4, $_a['activityId']);
                                $stmt->bindValue(5, $history_id);
                                $stmt->bindValue(6, 'Earn');
                                $stmt->bindValue(7, $earn_point);
                                $stmt->bindValue(8, 'A');
                                $stmt->bindValue(9, $datetime_now);
                                $stmt->bindValue(10, $user_id);
                                $stmt->bindValue(11, $datetime_now);
                                $stmt->bindValue(12, $user_id);
    
                                $stmt->execute();
                            }
                        }

                        if($_a['abId'] != '')
                        {
                            if(($customer_badge != -1 || $customer_badge > 0) && ($activity_badge != -1 || $activity_badge > 0))
                            {
                                $stmt = $db_cdpmkt->prepare('EXEC _Activity @type = ?, @activity_badge_id = ?, @campaign_id = ?, @sub_campaign_id = ?, @activity_id = ?, @badge_id = ?, @history_id = ?, @person_id = ?, @transaction_datetime = ?, @transaction_status = ?');
                        
                                $stmt->bindValue(1, 'Insert Badge');
                                $stmt->bindValue(2, $_a['abId']);
                                $stmt->bindValue(3, $_a['campId']);
                                $stmt->bindValue(4, $_a['subcampId']);
                                $stmt->bindValue(5, $_a['activityId']);
                                $stmt->bindValue(6, $_a['badgeId']);
                                $stmt->bindValue(7, $history_id);
                                $stmt->bindValue(8, $person_id);
                                $stmt->bindValue(9, $datetime_now);
                                $stmt->bindValue(10, 'A');
    
                                $stmt->execute();
                            }
                        }
                    }
                }
            }

            $db_cdpmkt->commit();
        }
        catch(Exception $ex)
        {
            $db_cdpmkt->rollBack();

            $__response_status_code = 500;
            $__response_data = array(
                'error' => array(
                    'errorType' => 'internal_error',
                    'message' => $ex->getMessage()
                ),
                'success' => false
            );
        }

        return $res->withJson($__response_data, $__response_status_code);
    }

    public function update_address(Request $req, Response $res, array $args)
    {
        $__response_status_code = 200;
        $__response_data = array();

        $db_cdpmkt = $this->db_cdpmkt;

        try
        {
            $db_cdpmkt->beginTransaction();

            $datetime_now = date('Y-m-d H:i:s');

            if($req->getHeader('Authorization'))
            {
                $req_authorization = $req->getHeader('Authorization')[0];
                $access_token = explode(' ', $req_authorization)[1];

                $__token = $this->validToken($access_token, $datetime_now);

                $__response_status_code = $__token['status'];
                $__response_data = $__token['data'];
            }
            else
            {
                $__response_status_code = 401;
                $__response_data = array(
                    'error' => array(
                        'errorType' => 'invalid_client',
                        'message' => 'Authorization header required.'
                    ),
                    'success' => false
                );

                return $res->withJson($__response_data, $__response_status_code);
            }

            $req_body = $req->getParsedBody();

            $field = array(
                'id',
                'address_type'
            );

            $_v = $this->isNullOrEmpty($field, $req_body);

            $__response_status_code = $_v['status'];
            $__response_data = $_v['detail'];

            if($__response_status_code != 200)
            {
                return $res->withJson($__response_data, $__response_status_code);
            }

            $person_id = (isset($req_body['id']) && $req_body['id'] != '') ? (int)$req_body['id'] : NULL;
            $address_id = (isset($req_body['address_id']) && $req_body['address_id'] != '') ? (int)$req_body['address_id'] : NULL;
            $address_type = (isset($req_body['address_type']) && $req_body['address_type'] != '') ? $req_body['address_type'] : NULL;
            $address_no = (isset($req_body['address_no']) && $req_body['address_no'] != '') ? $req_body['address_no'] : NULL;
            $sub_district_code = (isset($req_body['sub_district_code']) && $req_body['sub_district_code'] != '') ? (int)$req_body['sub_district_code'] : NULL;
            $district_code = (isset($req_body['district_code']) && $req_body['district_code'] != '') ? (int)$req_body['district_code'] : NULL;
            $province_code = (isset($req_body['province_code']) && $req_body['province_code'] != '') ? (int)$req_body['province_code'] : NULL;
            $postcode = (isset($req_body['postcode']) && $req_body['postcode'] != '') ? (int)$req_body['postcode'] : NULL;
            $is_default = (isset($req_body['address_default']) && $req_body['address_default'] === 'true') ? 'Y' : NULL;
            $session_id = (isset($req_body['session_id']) && $req_body['session_id'] != '') ? $req_body['session_id'] : NULL;
            $user_id = (isset($req_body['user_id']) ? $req_body['user_id'] : 1122);

            if(isset($req_body['address_id']) && !empty($address_id))
            {
                $stmt = $db_cdpmkt->prepare('EXEC _Person_Address @type = ?, @person_id = ?, @address_id = ?, @address_type = ?, @status = ?');
    
                $stmt->bindValue(1, 'Select');
                $stmt->bindValue(2, $req_body['id']);
                $stmt->bindValue(3, $req_body['address_id']);
                $stmt->bindValue(4, $req_body['address_type']);
                $stmt->bindValue(5, 'A');

                $stmt->execute();

                $_person = $stmt->fetch();

                if(!isset($_person['address_id']) || $_person['address_id'] == '')
                {
                    $__response_status_code = 400;
                    $__response_data = array(
                        'error' => array(
                            'errorType' => 'invalid_request',
                            'fieldName' => 'address_id',
                            'message' => 'address_id invalid.'
                        ),
                        'success' => false
                    );

                    return $res->withJson($__response_data, $__response_status_code);
                }
            }

            if(empty($address_id))
            {
                $stmt = $db_cdpmkt->prepare('EXEC _Person_Address @type = ?, @person_id = ?, @address_type = ?, @status = ?');
    
                $stmt->bindValue(1, 'Select');
                $stmt->bindValue(2, $req_body['id']);
                $stmt->bindValue(3, $req_body['address_type']);
                $stmt->bindValue(4, 'A');

                $stmt->execute();

                $_person = $stmt->fetch();

                if(isset($_person['address_id']) && $_person['address_id'] != '')
                {
                    $__response_status_code = 400;
                    $__response_data = array(
                        'error' => array(
                            'errorType' => 'invalid_request',
                            'fieldName' => 'address_type',
                            'message' => 'address_type(' . $req_body['address_type'] . ') already have.'
                        ),
                        'success' => false
                    );

                    return $res->withJson($__response_data, $__response_status_code);
                }
            }

            if($__response_status_code == 200)
            {
                if(!empty($address_id))
                {
                    $stmt = $db_cdpmkt->prepare('EXEC _Person_Address @type = ?, @address_id = ?, @address_type = ?, @address_no = ?, @sub_district_code = ?, @district_code = ?, @province_code = ?, @postcode = ?, @status = ?, @is_default = ?, @updatedatetime = ?, @updateby = ?');

                    $stmt->bindValue(1, 'Update');
                    $stmt->bindValue(2, $address_id);
                    $stmt->bindValue(3, $address_type);
                    $stmt->bindValue(4, $address_no);
                    $stmt->bindValue(5, $sub_district_code);
                    $stmt->bindValue(6, $district_code);
                    $stmt->bindValue(7, $province_code);
                    $stmt->bindValue(8, $postcode);
                    $stmt->bindValue(9, 'A');
                    $stmt->bindValue(10, $is_default);
                    $stmt->bindValue(11, $datetime_now);
                    $stmt->bindValue(12, $user_id);
    
                    $stmt->execute();
                }
                else
                {
                    $stmt = $db_cdpmkt->prepare('EXEC _Person_Address @type = ?, @person_id = ?, @member_no = ?, @address_type = ?, @address_no = ?, @sub_district_code = ?, @district_code = ?, @province_code = ?, @postcode = ?, @status = ?, @is_default = ?, @createdatetime = ?, @createby = ?, @updatedatetime = ?, @updateby = ?');

                    $stmt->bindValue(1, 'Insert');
                    $stmt->bindValue(2, $person_id);
                    $stmt->bindValue(3, NULL);
                    $stmt->bindValue(4, $address_type);
                    $stmt->bindValue(5, $address_no);
                    $stmt->bindValue(6, $sub_district_code);
                    $stmt->bindValue(7, $district_code);
                    $stmt->bindValue(8, $province_code);
                    $stmt->bindValue(9, $postcode);
                    $stmt->bindValue(10, 'A');
                    $stmt->bindValue(11, $is_default);
                    $stmt->bindValue(12, $datetime_now);
                    $stmt->bindValue(13, $user_id);
                    $stmt->bindValue(14, $datetime_now);
                    $stmt->bindValue(15, $user_id);
    
                    $stmt->execute();
                }

                $stmt = $db_cdpmkt->prepare('EXEC _Person_Session @type = ?, @person_id = ?, @session_id = ?, @status = ?');
    
                $stmt->bindValue(1, 'Select');
                $stmt->bindValue(2, $person_id);
                $stmt->bindValue(3, $session_id);
                $stmt->bindValue(4, 'Active');

                $stmt->execute();
                
                if(count($stmt->fetchAll()) == 0)
                {
                    $stmt = $db_cdpmkt->prepare('EXEC _Person_Session @type = ?, @person_id = ?, @session_id = ?, @status = ?, @createdatetime = ?, @updatedatetime = ?');

                    $stmt->bindValue(1, 'Insert');
                    $stmt->bindValue(2, $person_id);
                    $stmt->bindValue(3, $session_id);
                    $stmt->bindValue(4, 'Active');
                    $stmt->bindValue(5, $datetime_now);
                    $stmt->bindValue(6, $datetime_now);
    
                    $stmt->execute();
                }

                $__response_status_code = 200;
                $__response_data = array(
                    'response_body' => array(
                        'message' => 'Update data success.'
                    ),
                    'success' => true
                );
            }         

            $db_cdpmkt->commit();
        }
        catch(Exception $ex)
        {
            $db_cdpmkt->rollBack();

            $__response_status_code = 500;
            $__response_data = array(
                'error' => array(
                    'errorType' => 'internal_error',
                    'message' => $ex->getMessage()
                ),
                'success' => false
            );
        }

        return $res->withJson($__response_data, $__response_status_code);
    }

    public function update_data(Request $req, Response $res, array $args)
    {
        $__response_status_code = 200;
        $__response_data = array();

        $db_cdpmkt = $this->db_cdpmkt;

        try
        {
            $db_cdpmkt->beginTransaction();

            $datetime_now = date('Y-m-d H:i:s');

            if($req->getHeader('Authorization'))
            {
                $req_authorization = $req->getHeader('Authorization')[0];
                $access_token = explode(' ', $req_authorization)[1];

                $__token = $this->validToken($access_token, $datetime_now);

                $__response_status_code = $__token['status'];
                $__response_data = $__token['data'];
            }
            else
            {
                $__response_status_code = 401;
                $__response_data = array(
                    'error' => array(
                        'errorType' => 'invalid_client',
                        'message' => 'Authorization header required.'
                    ),
                    'success' => false
                );

                return $res->withJson($__response_data, $__response_status_code);
            }

            $req_body = $req->getParsedBody();

            if($__response_status_code == 200 && isset($req_body['date_of_birth']) && $req_body['date_of_birth'] != '' && !$this->validateDate($req_body['date_of_birth']))
            {
                $__response_status_code = 400;
                $__response_data = array(
                    'error' => array(
                        'errorType' => 'invalid_request',
                        'fieldName' => 'date_of_birth',
                        'message' => 'date_of_birth invalid.'
                    ),
                    'success' => false
                );
            }

            if($__response_status_code == 200 && !isset($req_body['id']))
            {
                $__response_status_code = 400;
                $__response_data = array(
                    'error' => array(
                        'errorType' => 'invalid_request',
                        'fieldName' => 'id',
                        'message' => 'Missing parameters: id'
                    ),
                    'success' => false
                );
            }

            if($__response_status_code == 200 && $req_body['id'] == '')
            {
                $__response_status_code = 400;
                $__response_data = array(
                    'error' => array(
                        'errorType' => 'invalid_request',
                        'fieldName' => 'id',
                        'message' => 'Missing id parameter value.'
                    ),
                    'success' => false
                );
            }

            if($__response_status_code == 200 && $req_body['id'] != '')
            {
                $stmt = $db_cdpmkt->prepare('EXEC _Person @type = ?, @person_id = ?');

                $stmt->bindValue(1, 'Select');
                $stmt->bindValue(2, $req_body['id']);

                $stmt->execute();
                
                if(count($stmt->fetchAll()) == 0)
                {
                    $__response_status_code = 400;
                    $__response_data = array(
                        'error' => array(
                            'errorType' => 'invalid_request',
                            'fieldName' => 'id',
                            'message' => 'id invalid.'
                        ),
                        'success' => false
                    );
                }
            }

            if($__response_status_code == 200 && !isset($req_body['session_id']))
            {
                $__response_status_code = 400;
                $__response_data = array(
                    'error' => array(
                        'errorType' => 'invalid_request',
                        'fieldName' => 'session_id',
                        'message' => 'Missing parameters: session_id'
                    ),
                    'success' => false
                );
            }

            if($__response_status_code == 200 && $req_body['session_id'] == '')
            {
                $__response_status_code = 400;
                $__response_data = array(
                    'error' => array(
                        'errorType' => 'invalid_request',
                        'fieldName' => 'session_id',
                        'message' => 'Missing session_id parameter value.'
                    ),
                    'success' => false
                );
            }

            $person_id = $req_body['id'];

            $stmt = $db_cdpmkt->prepare('EXEC _Person @type = ?, @person_id = ?, @status = ?');

            $stmt->bindValue(1, 'Select');
            $stmt->bindValue(2, $person_id);
            $stmt->bindValue(3, 'A');

            $stmt->execute();

            $__person = $stmt->fetch();

            if($__response_status_code == 200 && isset($req_body['verify_email']))
            {
                if($req_body['verify_email'] == '')
                {
                    $__response_status_code = 400;
                    $__response_data = array(
                        'error' => array(
                            'errorType' => 'invalid_request',
                            'fieldName' => 'verify_email',
                            'message' => 'Missing verify_email parameter value.'
                        ),
                        'success' => false
                    );
                }
                else
                {
                    $verify_email = (isset($req_body['verify_email']) && $req_body['verify_email'] === 'true') ? 'Y' : NULL;

                    $stmt = $db_cdpmkt->prepare('EXEC _Person @type = ?, @email = ?, @verify_email = ?, @status = ?, @is_member = ?');
    
                    $stmt->bindValue(1, 'Select');
                    $stmt->bindValue(2, $__person['email']);
                    $stmt->bindValue(3, $verify_email);
                    $stmt->bindValue(4, 'A');
                    $stmt->bindValue(5, 'Y');
    
                    $stmt->execute();
    
                    $_person = $stmt->fetch();
    
                    if(isset($_person['personId']) && $_person['personId'] != '')
                    {
                        $__response_status_code = 400;
                        $__response_data = array(
                            'error' => array(
                                'errorType' => 'invalid_request',
                                'fieldName' => 'email',
                                'message' => 'email already used.'
                            ),
                            'success' => false
                        );
                    }
                }
            }

            if($__response_status_code == 200 && isset($req_body['line_user_id']))
            {
                if($req_body['line_user_id'] == '')
                {
                    $__response_status_code = 400;
                    $__response_data = array(
                        'error' => array(
                            'errorType' => 'invalid_request',
                            'fieldName' => 'line_user_id',
                            'message' => 'Missing line_user_id parameter value.'
                        ),
                        'success' => false
                    );
                }
                else
                {
                    $line_user_id = (isset($req_body['line_user_id']) && $req_body['line_user_id'] != '') ? $req_body['line_user_id'] : NULL;

                    $stmt = $db_cdpmkt->prepare('EXEC _Person_Social @type = ?, @social_type = ?, @social_value = ?, @status = ?');
    
                    $stmt->bindValue(1, 'Select');
                    $stmt->bindValue(2, 'Line');
                    $stmt->bindValue(3, $line_user_id);
                    $stmt->bindValue(4, 'A');

                    $stmt->execute();

                    $_person = $stmt->fetch();
    
                    if(isset($_person['socialId']) && $_person['socialId'] != '')
                    {
                        $__response_status_code = 400;
                        $__response_data = array(
                            'error' => array(
                                'errorType' => 'invalid_request',
                                'fieldName' => 'line_user_id',
                                'message' => 'line_user_id already used.'
                            ),
                            'success' => false
                        );
                    }
                }
            }

            if($__response_status_code == 200)
            {
                if($__person && isset($__person['personId']) && $__person['personId'] != '')
                {
                    $career = (isset($req_body['career']) ? $req_body['career'] : NULL);
                    $career_level = (isset($req_body['career_level']) ? $req_body['career_level'] : NULL);
                    $chanel = (isset($req_body['chanel']) ? $req_body['chanel'] : NULL);
                    $consent = (isset($req_body['consent']) ? ($req_body['consent'] === 'true' ? 'Y' : 'N') : NULL);
                    $device = (isset($req_body['device']) ? $req_body['device'] : NULL);
                    $date_of_birth = (isset($req_body['date_of_birth']) ? $req_body['date_of_birth'] : NULL);
                    $education_id = (isset($req_body['education_id']) ? $req_body['education_id'] : NULL);
                    $email = (isset($req_body['email']) ? $req_body['email'] : NULL);
                    $firstname = (isset($req_body['firstname']) ? $req_body['firstname'] : NULL);
                    $gender = (isset($req_body['gender']) ? ($req_body['gender'] == 'Male' ? 'M' : ($req_body['gender'] == 'Female' ? 'F' : NULL)) : NULL);
                    $id_card_no = (isset($req_body['id_card_no']) ? $req_body['id_card_no'] : NULL);
                    $is_member = (isset($req_body['is_member']) ? $req_body['is_member'] : NULL);
                    $lastname = (isset($req_body['lastname']) ? $req_body['lastname'] : NULL);
                    $line_user_id = (isset($req_body['line_user_id']) ? $req_body['line_user_id'] : NULL);
                    $line_display_name = (isset($req_body['line_display_name']) ? $req_body['line_display_name'] : NULL);
                    $line_picture_url = (isset($req_body['line_picture_url']) ? $req_body['line_picture_url'] : NULL);
                    $line_status_message = (isset($req_body['line_status_message']) ? $req_body['line_status_message'] : NULL);
                    $member_number_ref = (isset($req_body['member_number_ref']) ? $req_body['member_number_ref'] : NULL);
                    $register_status = (isset($req_body['member_number_ref']) ? ($req_body['member_number_ref'] != '' ? 'Existing' : 'New') : 'New');
                    $member_status = (isset($req_body['member_status']) ? $req_body['member_status'] : NULL);
                    $mobile_no = (isset($req_body['mobile_no']) ? $req_body['mobile_no'] : NULL);
                    $nationality = (isset($req_body['nationality']) ? $req_body['nationality'] : NULL);
                    $not_idcard = (isset($req_body['not_idcard']) ? $req_body['not_idcard'] : NULL);
                    $not_phone = (isset($req_body['not_phone']) ? $req_body['not_phone'] : NULL);
                    $number_of_child = (isset($req_body['number_of_child']) ? $req_body['number_of_child'] : NULL);
                    $number_of_family = (isset($req_body['number_of_family']) ? $req_body['number_of_family'] : NULL);
                    $occupation = (isset($req_body['occupation']) ? $req_body['occupation'] : NULL);
                    $old_tier_id = NULL;
                    $passport_no = (isset($req_body['passport_no']) ? $req_body['passport_no'] : NULL);
                    $password = (isset($req_body['password']) ? hash('sha256', $req_body['password']) : NULL);
                    $person_id = (isset($req_body['id']) ? $req_body['id'] : NULL);
                    $person_status = (isset($req_body['person_status']) ? $req_body['person_status'] : NULL);
                    $point = (isset($req_body['point']) ? $req_body['point'] : NULL);
                    $point_bonus = (isset($req_body['point_bonus']) ? $req_body['point_bonus'] : NULL);
                    $point_accumulate = (isset($req_body['point_accumulate']) ? $req_body['point_accumulate'] : NULL);
                    $point_spending = (isset($req_body['point_spending']) ? $req_body['point_spending'] : NULL);
                    $point_balance = (isset($req_body['point_balance']) ? $req_body['point_balance'] : NULL);
                    $preferred_channel = (isset($req_body['preferred_channel']) ? $req_body['preferred_channel'] : NULL);
                    $religion = (isset($req_body['religion']) ? $req_body['religion'] : NULL);
                    $register_type = (isset($req_body['register_type']) ? $req_body['register_type'] : NULL);
                    $remark = (isset($req_body['remark']) ? $req_body['remark'] : NULL);
                    $salary = (isset($req_body['salary']) ? $req_body['salary'] : NULL);
                    $session_id = (isset($req_body['session_id']) ? $req_body['session_id'] : NULL);
                    $subscribe = (isset($req_body['subscribe']) ? ($req_body['subscribe'] === 'true' ? 'Email' : NULL) : NULL);
                    $tier_id = (isset($req_body['tier_id']) ? $req_body['tier_id'] : NULL);
                    $verify_id_card = (isset($req_body['verify_id_card']) ? ($req_body['verify_id_card'] === 'true' ? 'Y' : NULL) : NULL);
                    $verify_email = (isset($req_body['verify_email']) ? ($req_body['verify_email'] === 'true' ? 'Y' : NULL) : NULL);
                    $verify_phone = (isset($req_body['verify_phone']) ? ($req_body['verify_phone'] === 'true' ? 'Y' : NULL) : NULL);            
                    $user_id = (isset($req_body['user_id']) ? $req_body['user_id'] : 1122);

                    $stmt = $db_cdpmkt->prepare('EXEC _Person @type = ?, @person_id = ?, @ti_id = ?, @memb_type = ?, @memberNoRef = ?, @firstname = ?, @lastname = ?, @gender = ?, @birthdate = ?, @age = ?, @id_card = ?, @passport = ?, @email = ?, @password = ?, @mobile_no = ?, @nation_code = ?, @person_point = ?, @person_point_bonus = ?, @person_point_accumulate = ?, @person_point_spending = ?, @person_point_balance = ?, @education_id = ?, @occupation = ?, @career_level = ?, @career = ?, @salary = ?, @number_of_child = ?, @number_of_family = ?, @religion = ?, @chanel = ?, @device = ?, @preferred_channel = ?, @memberexpire = ?, @not_phone = ?, @not_idcard = ?, @verify_phone = ?, @verify_email = ?, @verify_idcard = ?, @is_member = ?, @is_consent = ?, @remark = ?, @person_status = ?, @person_member_status = ?, @registerdatetime = ?, @createdatetime = ?, @createby = ?, @updatedatetime = ?, @lastupdateby = ?');
        
                    $stmt = $this->bindValue($stmt, array(
                        'type' => 'Update',
                        'person_id' => $person_id,
                        'ti_id' => $tier_id,
                        'memb_type' => $register_type,
                        'memberNoRef' => $member_number_ref,
                        'firstname' => $firstname,
                        'lastname' => $lastname,
                        'gender' => $gender,
                        'birthdate' => $date_of_birth,
                        'age' => NULL,
                        'id_card' => $id_card_no,
                        'passport' => $passport_no,
                        'email' => $email,
                        'password' => $password,
                        'mobile_no' => $mobile_no,
                        'nation_code' => $nationality,
                        'person_point' => $point,
                        'person_point_bonus' => $point_bonus,
                        'person_point_accumulate' => $point_accumulate,
                        'person_point_spending' => $point_spending,
                        'person_point_balance' => $point_balance,
                        'education_id' => $education_id,
                        'occupation' => $occupation,
                        'career_level' => $career_level,
                        'career' => $career,
                        'salary' => $salary,
                        'number_of_child' => $number_of_child,
                        'number_of_family' => $number_of_family,
                        'religion' => $religion,
                        'chanel' => $chanel,
                        'device' => $device,
                        'preferred_channel' => $subscribe,
                        'memberexpire' => NULL,
                        'not_phone' => $not_phone,
                        'not_idcard' => $not_idcard,
                        'verify_phone' => $verify_phone,
                        'verify_email' => $verify_email,
                        'verify_idcard' => $verify_phone,
                        'is_member' => $is_member,
                        'is_consent' => $consent,
                        'remark' => $remark,
                        'person_status' => $person_status,
                        'person_member_status' => $member_status,
                        'registerdatetime' => $datetime_now,
                        'createdatetime' => $datetime_now,
                        'createby' => $user_id,
                        'updatedatetime' => $datetime_now,
                        'lastupdateby' => $user_id,
                    ));
    
                    $stmt->execute();
    
                    if($line_user_id != '')
                    {
                        $stmt = $db_cdpmkt->prepare('EXEC _Person_Social @type = ?, @person_id = ?, @social_type = ?, @status = ?');

                        $stmt = $this->bindValue($stmt, array(
                            'type' => 'Select',
                            'person_id' => $person_id,
                            'social_type' => 'Line',
                            'status' => 'A'
                        ));

                        $stmt->execute();

                        if(count($stmt->fetchAll()) == 0)
                        {
                            $stmt = $db_cdpmkt->prepare('EXEC _Person_Social @type = ?, @person_id = ?, @social_type = ?, @social_value = ?, @social_name = ?, @social_picture_url = ?, @social_status_message = ?, @status = ?, @createdatetime = ?, @creaetby = ?, @updatedatetime = ?, @updateby = ?');

                            $stmt = $this->bindValue($stmt, array(
                                'type' => 'Select',
                                'person_id' => $person_id,
                                'social_type' => 'Line',
                                'social_value' => $line_user_id,
                                'social_name' => $line_display_name,
                                'social_picture_url' => $line_picture_url,
                                'social_status_message' => $line_status_message,
                                'status' => 'A',
                                'createdatetime' => $datetime_now,
                                'creaetby' => $user_id,
                                'updatedatetime' => $datetime_now,
                                'updateby' => $user_id
                            ));

                            $stmt->execute();
                        }
                        else
                        {
                            $stmt = $db_cdpmkt->prepare('EXEC _Person_Social @type = ?, @person_id = ?, @social_type = ?, @social_value = ?, @social_name = ?, @social_picture_url = ?, @social_status_message = ?, @status = ?, @updatedatetime = ?, @updateby = ?');

                            $stmt = $this->bindValue($stmt, array(
                                'type' => 'Update',
                                'person_id' => $person_id,
                                'social_type' => 'Line',
                                'social_value' => $line_user_id,
                                'social_name' => $line_display_name,
                                'social_picture_url' => $line_picture_url,
                                'social_status_message' => $line_status_message,
                                'status' => 'A',
                                'updatedatetime' => $datetime_now,
                                'updateby' => $user_id
                            ));
            
                            $stmt->execute();
                        }
                    }
    
                    $stmt = $db_cdpmkt->prepare('EXEC _Person_Session @type = ?, @person_id = ?, @session_id = ?, @status = ?');
    
                    $stmt->bindValue(1, 'Select');
                    $stmt->bindValue(2, $person_id);
                    $stmt->bindValue(3, $session_id);
                    $stmt->bindValue(4, 'Active');
    
                    $stmt->execute();
                    
                    if(count($stmt->fetchAll()) == 0)
                    {
                        $stmt = $db_cdpmkt->prepare('EXEC _Person_Session @type = ?, @person_id = ?, @session_id = ?, @status = ?, @createdatetime = ?, @updatedatetime = ?');
    
                        $stmt->bindValue(1, 'Insert');
                        $stmt->bindValue(2, $person_id);
                        $stmt->bindValue(3, $session_id);
                        $stmt->bindValue(4, 'Active');
                        $stmt->bindValue(5, $datetime_now);
                        $stmt->bindValue(6, $datetime_now);
        
                        $stmt->execute();
                    }
    
                    $__response_status_code = 200;
                    $__response_data = array(
                        'response_body' => array(
                            'message' => 'Update data success.'
                        ),
                        'success' => true
                    );
                }
                else
                {
                    $__response_status_code = 200;
                    $__response_data = array(
                        'response_body' => array(
                            'message' => 'Member not found.'
                        ),
                        'success' => true
                    );
                }
            }

            $db_cdpmkt->commit();
        }
        catch(Exception $ex)
        {
            $db_cdpmkt->rollBack();

            $__response_status_code = 500;
            $__response_data = array(
                'error' => array(
                    'errorType' => 'internal_error',
                    'message' => $ex->getMessage()
                ),
                'success' => false
            );
        }

        return $res->withJson($__response_data, $__response_status_code);
    }

    public function verify(Request $req, Response $res, array $args)
    {
        $__response_status_code = 200;
        $__response_data = array();

        $db_cdpmkt = $this->db_cdpmkt;

        try
        {
            $datetime_now = date('Y-m-d H:i:s');

            if($req->getHeader('Authorization'))
            {
                $req_authorization = $req->getHeader('Authorization')[0];
                $access_token = explode(' ', $req_authorization)[1];

                $__token = $this->validToken($access_token, $datetime_now);

                $__response_status_code = $__token['status'];
                $__response_data = $__token['data'];
            }
            else
            {
                $__response_status_code = 401;
                $__response_data = array(
                    'error' => array(
                        'errorType' => 'invalid_client',
                        'message' => 'Authorization header required.'
                    ),
                    'success' => false
                );

                return $res->withJson($__response_data, $__response_status_code);
            }

            $req_body = $req->getParsedBody();

            if($__response_status_code == 200 && isset($req_body['mobile_no']) && $req_body['mobile_no'] == '')
            {
                $__response_status_code = 400;
                $__response_data = array(
                    'error' => array(
                        'errorType' => 'invalid_request',
                        'fieldName' => 'mobile_no',
                        'message' => 'Missing mobile_no parameter value.'
                    ),
                    'success' => false
                );
            }

            if($__response_status_code == 200 && isset($req_body['email']) && $req_body['email'] == '')
            {
                $__response_status_code = 400;
                $__response_data = array(
                    'error' => array(
                        'errorType' => 'invalid_request',
                        'fieldName' => 'email',
                        'message' => 'Missing email parameter value.'
                    ),
                    'success' => false
                );
            }

            if($__response_status_code == 200 && isset($req_body['email']) || isset($req_body['phone']))
            {
                if(!isset($req_body['password']))
                {
                    $__response_status_code = 400;
                    $__response_data = array(
                        'error' => array(
                            'errorType' => 'invalid_request',
                            'fieldName' => 'password',
                            'message' => 'Missing parameters: password'
                        ),
                        'success' => false
                    );
                }
                else if($req_body['password'] == '')
                {
                    $__response_status_code = 400;
                    $__response_data = array(
                        'error' => array(
                            'errorType' => 'invalid_request',
                            'fieldName' => 'password',
                            'message' => 'Missing password parameter value.'
                        ),
                        'success' => false
                    );
                }
            }

            if($__response_status_code == 200 && isset($req_body['line_user_id']) && $req_body['line_user_id'] == '')
            {
                $__response_status_code = 400;
                $__response_data = array(
                    'error' => array(
                        'errorType' => 'invalid_request',
                        'fieldName' => 'line_user_id',
                        'message' => 'Missing line_user_id parameter value.'
                    ),
                    'success' => false
                );
            }

            if($__response_status_code == 200)
            {
                $mobile_no = (isset($req_body['mobile_no']) && $req_body['mobile_no'] != '') ? $req_body['mobile_no'] : NULL;
                $email = (isset($req_body['email']) && $req_body['email'] != '') ? $req_body['email'] : NULL;
                $password = (isset($req_body['password']) && $req_body['password'] != '') ? hash('sha256', $req_body['password']) : NULL;
                $line_user_id = (isset($req_body['line_user_id']) && $req_body['line_user_id'] != '') ? $req_body['line_user_id'] : NULL;
                $verify_phone = (isset($req_body['mobile_no']) && $req_body['mobile_no'] != '') ? 'Y' : NULL;
                $verify_email = (isset($req_body['email']) && $req_body['email'] != '') ? 'Y' : NULL;

                $stmt = $db_cdpmkt->prepare('EXEC _Person @type = ?, @mobile_no = ?, @email = ?, @line_user_id = ?, @exclude_person_status = ?, @is_member = ?, @verify_phone = ?, @verify_email = ?');
    
                $stmt->bindValue(1, 'Select');
                $stmt->bindValue(2, $mobile_no);
                $stmt->bindValue(3, $email);
                $stmt->bindValue(4, $line_user_id);
                $stmt->bindValue(5, 'D');
                $stmt->bindValue(6, 'Y');
                $stmt->bindValue(7, $verify_phone);
                $stmt->bindValue(8, $verify_email);

                $stmt->execute();

                $__person = $stmt->fetch();

                if(!isset($__person['personId']) || $__person['personId'] == '')
                {
                    $__response_status_code = 200;
                    $__response_data = array(
                        'response_body' => array(
                            'message' => 'Member not found.'
                        ),
                        'success' => false
                    );
                }
                else
                {
                    if(($mobile_no != '' || $email != '') && $__person['password'] != $password)
                    {
                        $__response_status_code = 200;
                        $__response_data = array(
                            'response_body' => array(
                                'message' => 'Password invalid.'
                            ),
                            'success' => false
                        );
                    }
                    else if($mobile_no != '' && $__person['verify_phone'] != 'Y')
                    {
                        $__response_status_code = 200;
                        $__response_data = array(
                            'response_body' => array(
                                'message' => 'Mobile number is not verify.'
                            ),
                            'success' => false
                        );
                    }
                    else if($email != '' && $__person['verify_email'] != 'Y')
                    {
                        $__response_status_code = 200;
                        $__response_data = array(
                            'response_body' => array(
                                'message' => 'Email is not verify.'
                            ),
                            'success' => false
                        );
                    }
                    else
                    {
                        $member = array();
    
                        $firstname = ($__person['firstname'] == null) ? '' : $__person['firstname'];
                        $lastname = ($__person['lastname'] == null) ? '' : $__person['lastname'];
        
                        $member[] = array(
                            'id' => (int)$__person['personId'],
                            'firstname' => $firstname,
                            'lastname' => $lastname
                        );
        
                        $__response_data = array(
                            'response_body' => array(
                                'person' => $member
                            ),
                            'success' => true
                        );
                    }
                }
            }
        }
        catch(Exception $ex)
        {
            $__response_status_code = 500;
            $__response_data = array(
                'error' => array(
                    'errorType' => 'internal_error',
                    'message' => $ex->getMessage()
                ),
                'success' => false
            );
        }

        return $res->withJson($__response_data, $__response_status_code);
    }

    public function profile(Request $req, Response $res, array $args)
    {
        $__response_status_code = 200;
        $__response_data = array();

        $db_cdpmkt = $this->db_cdpmkt;

        try
        {
            $datetime_now = date('Y-m-d H:i:s');

            if($req->getHeader('Authorization'))
            {
                $req_authorization = $req->getHeader('Authorization')[0];
                $access_token = explode(' ', $req_authorization)[1];

                $__token = $this->validToken($access_token, $datetime_now);

                $__response_status_code = $__token['status'];
                $__response_data = $__token['data'];
            }
            else
            {
                $__response_status_code = 401;
                $__response_data = array(
                    'error' => array(
                        'errorType' => 'invalid_client',
                        'message' => 'Authorization header required.'
                    ),
                    'success' => false
                );

                return $res->withJson($__response_data, $__response_status_code);
            }

            $req_body = $req->getParsedBody();

            $field = array(
                'id'
            );

            $_v = $this->isNullOrEmpty($field, $req_body);

            $__response_status_code = $_v['status'];
            $__response_data = $_v['detail'];

            $person_id = (isset($req_body['id']) ? $req_body['id'] : NULL);
            $is_member = (isset($req_body['is_member']) ? $req_body['is_member'] : NULL);

            if($__response_status_code == 200)
            {
                $stmt = $db_cdpmkt->prepare('EXEC _Person @type = ?, @person_id = ?, @status = ?, @is_member = ?');

                $stmt->bindValue(1, 'Profile');
                $stmt->bindValue(2, $person_id);                
                $stmt->bindValue(3, 'A');
                $stmt->bindValue(4, $is_member);

                $stmt->execute();

                $_person = $stmt->fetch();

                if(!isset($_person['personId']) || $_person['personId'] == '')
                {
                    $__response_status_code = 200;
                    $__response_data = array(
                        'response_body' => array(
                            'message' => 'Member not found.'
                        ),
                        'success' => false
                    );
                }
                else
                {
                    $stmt = $db_cdpmkt->prepare('EXEC _Person_Address @type = ?, @person_id = ?, @status = ?');

                    $stmt->bindValue(1, 'Select');
                    $stmt->bindValue(2, $req_body['id']);
                    $stmt->bindValue(3, 'A');
    
                    $stmt->execute();
    
                    $_address = $stmt->fetchAll();
    
                    $address = array();
                    $member = array();
                    $social = array();
    
                    $is_member = (isset($_person['is_member']) && $_person['is_member'] == 'Y') ? true : false;
                    $verify_phone = (isset($_person['verify_phone']) && $_person['verify_phone'] == 'Y') ? true : false;
                    $firstname = (isset($_person['firstname']) && $_person['firstname'] != null) ? $_person['firstname'] : '';
                    $lastname = (isset($_person['lastname']) && $_person['lastname'] != null) ? $_person['lastname'] : '';
                    $mobile_no = (isset($_person['mobileNo']) && $_person['mobileNo'] != null) ? $_person['mobileNo'] : '';
                    $email = (isset($_person['email']) && $_person['email'] != null) ? $_person['email'] : '';
                    $date_of_birth = (isset($_person['birthdate']) && $_person['birthdate'] != null) ? $_person['birthdate'] : '';
                    $age = (isset($_person['age']) && $_person['age'] != null) ? (int)$_person['age'] : '';
    
                    if($_person['gender'] == 'M')
                    {
                        $gender = 'Male';
                    }
                    else if($_person['gender'] == 'F')
                    {
                        $gender = 'Female';
                    }
                    else
                    {
                        $gender = '';
                    }
                    
                    $id_card_no = (isset($_person['idCardNo']) && $_person['idCardNo'] != null) ? $_person['idCardNo'] : '';
                    $naiotality_code = (isset($_person['nationCode']) && $_person['nationCode'] != null) ? $_person['nationCode'] : '';
                    $naiotality = (isset($_person['nationNameThai']) && $_person['nationNameThai'] != null) ? $_person['nationNameThai'] : '';
                    $passport_no = (isset($_person['passportNo']) && $_person['passportNo'] != null) ? $_person['passportNo'] : '';
                    $is_consent = (isset($_person['is_consent']) && $_person['is_consent'] == 'Y') ? true : false;
                    $is_subscribe = (isset($_person['preferredChannel']) && $_person['preferredChannel'] == 'Email') ? true : false;
                    $tier_name = (isset($_person['ti_name']) && $_person['ti_name'] != null) ? $_person['ti_name'] : '';
                    $point_accumulate = (isset($_person['person_point_accumulate']) && $_person['person_point_accumulate'] != null) ? (int)$_person['person_point_accumulate'] : 0;
                    $point_spending = (isset($_person['person_point_spending']) && $_person['person_point_spending'] != null) ? (int)$_person['person_point_spending'] : 0;
                    $point_balance = (isset($_person['person_point_balance']) && $_person['person_point_balance'] != null) ? (int)$_person['person_point_balance'] : 0;
                    $line_user_id = (isset($_person['line_user_id']) && $_person['line_user_id'] != null) ? $_person['line_user_id'] : '';
                    $register_datetime = (isset($_person['register_datetime']) && $_person['register_datetime'] != null) ? $_person['register_datetime'] : '';
                    $point_expire = new \DateTime('1st January Next Year');

    
                    if($line_user_id != '')
                    {
                        $social[] = array(
                            'type' => 'Line',
                            'user_id' => $line_user_id
                        );
                    }                
    
                    $member = array(
                        'id' => (int)$_person['personId'],
                        'member_no' => $_person['memberNo'],
                        'tier' => $tier_name,
                        'firstname' => $firstname,
                        'lastname' => $lastname,
                        'date_of_birth' => $date_of_birth,
                        'age' => $age,
                        'mobile_no' => $mobile_no,
                        'email' => $email,
                        'gender' => $gender,
                        'id_card_no' => $id_card_no,
                        'consent' => $is_consent,
                        'subscribe' => $is_subscribe,
                        'nationality_code' => $naiotality_code,
                        'nationality' => $naiotality,
                        'passport_no' => $passport_no,
                        'point_accumulate' => $point_accumulate,
                        'point_spending' => $point_spending,
                        'point_balance' => $point_balance,
                        'point_expire' => $point_expire->format('Y-m-d'),
                        'register_datetime' => $register_datetime
                    );
    
                    foreach($_address as $__address)
                    {
                        $address_id = (isset($__address['address_id']) && $__address['address_id'] != null) ? (int)$__address['address_id'] : '';
                        $address_type = (isset($__address['address_type']) && $__address['address_type'] != null) ? $__address['address_type'] : '';
                        $address_no = (isset($__address['address_no']) && $__address['address_no'] != null) ? $__address['address_no'] : '';
                        $sub_district_code = (isset($__address['sub_district_code']) && $__address['sub_district_code'] != null) ? (int)$__address['sub_district_code'] : '';
                        $sub_district_th = (isset($__address['sub_district_th']) && $__address['sub_district_th'] != null) ? $__address['sub_district_th'] : '';
                        $sub_district_en = (isset($__address['sub_district_en']) && $__address['sub_district_en'] != null) ? $__address['sub_district_en'] : '';
                        $district_code = (isset($__address['district_code']) && $__address['district_code'] != null) ? (int)$__address['district_code'] : '';
                        $district_th = (isset($__address['district_th']) && $__address['district_th'] != null) ? $__address['district_th'] : '';
                        $district_en = (isset($__address['district_en']) && $__address['district_en'] != null) ? $__address['district_en'] : '';
                        $province_code = (isset($__address['province_code']) && $__address['province_code'] != null) ? (int)$__address['province_code'] : '';
                        $province_th = (isset($__address['province_th']) && $__address['province_th'] != null) ? $__address['province_th'] : '';
                        $province_en = (isset($__address['province_en']) && $__address['province_en'] != null) ? $__address['province_en'] : '';
                        $region_th = (isset($__address['region_th']) && $__address['region_th'] != null) ? $__address['region_th'] : '';
                        $region_en = (isset($__address['region_en']) && $__address['region_en'] != null) ? $__address['region_en'] : '';
                        $postcode = (isset($__address['postcode']) && $__address['postcode'] != null) ? (int)$__address['postcode'] : '';
                        $is_default = (isset($__address['is_default']) && $__address['is_default'] != null) ? true : false;
    
                        $address[] = array(
                            'id' => $address_id,
                            'type' => $address_type,
                            'address_no' => $address_no,
                            'sub_district_code' => $sub_district_code,
                            'sub_district_th' => $sub_district_th,
                            'sub_district_en' => $sub_district_en,
                            'district_code' => $district_code,
                            'district_th' => $district_th,
                            'district_en' => $district_en,
                            'province_code' => $province_code,
                            'province_th' => $province_th,
                            'province_en' => $province_en,
                            'region_th' => $region_th,
                            'region_en' => $region_en,
                            'postcode' => $postcode,
                            'is_default' => $is_default
                        );
                    }
    
                    if(count($social) > 0)
                    {
                        $member['social'] = $social;
                    }
    
                    if(count($address) > 0)
                    {
                        $member['address'] = $address;
                    }
    
                    $__response_data = array(
                        'response_body' => array(
                            'is_member' => $is_member,
                            'verify_phone' => $verify_phone,
                            'person' => $member
                        ),
                        'success' => true
                    );
                }
            }
        }
        catch(Exception $ex)
        {
            $__response_status_code = 500;
            $__response_data = array(
                'error' => array(
                    'errorType' => 'internal_error',
                    'message' => $ex->getMessage()
                ),
                'success' => false
            );
        }

        return $res->withJson($__response_data, $__response_status_code);
    }

    public function change_password(Request $req, Response $res, array $args)
    {
        $__response_status_code = 200;
        $__response_data = array();

        $db_cdpmkt = $this->db_cdpmkt;

        try
        {
            $datetime_now = date('Y-m-d H:i:s');

            if($req->getHeader('Authorization'))
            {
                $req_authorization = $req->getHeader('Authorization')[0];
                $access_token = explode(' ', $req_authorization)[1];

                $__token = $this->validToken($access_token, $datetime_now);

                $__response_status_code = $__token['status'];
                $__response_data = $__token['data'];
            }
            else
            {
                $__response_status_code = 401;
                $__response_data = array(
                    'error' => array(
                        'errorType' => 'invalid_client',
                        'message' => 'Authorization header required.'
                    ),
                    'success' => false
                );

                return $res->withJson($__response_data, $__response_status_code);
            }

            $req_body = $req->getParsedBody();

            $field = array(
                'id',
                'password',
                'new_password',
            );

            $_v = $this->isNullOrEmpty($field, $req_body);

            $__response_status_code = $_v['status'];
            $__response_data = $_v['detail'];

            if($__response_status_code == 200)
            {
                $stmt = $db_cdpmkt->prepare('EXEC _Person @type = ?, @person_id = ?, @status = ?, @is_member = ?');

                $stmt->bindValue(1, 'Select');
                $stmt->bindValue(2, $req_body['id']);
                $stmt->bindValue(3, 'A');
                $stmt->bindValue(4, 'Y');

                $stmt->execute();

                $_person = $stmt->fetch();

                if(!isset($_person['personId']) || $_person['personId'] == '')
                {
                    $__response_status_code = 200;
                    $__response_data = array(
                        'response_body' => array(
                            'message' => 'Member not found.'
                        ),
                        'success' => false
                    );
                }
                else if(isset($_person['personId']) && $_person['personId'] != '' && $_person['password'] != hash("sha256", $req_body['password']))
                {
                    $__response_status_code = 400;
                    $__response_data = array(
                        'error' => array(
                            'errorType' => 'invalid_request',
                            'fieldName' => 'password',
                            'message' => 'password invalid.'
                        ),
                        'success' => false
                    );
                }
                else
                {
                    $stmt = $db_cdpmkt->prepare('EXEC _Person @type = ?, @person_id = ?, @password = ?');

                    $stmt->bindValue(1, 'Update');
                    $stmt->bindValue(2, $req_body['id']);
                    $stmt->bindValue(3, hash("sha256", $req_body['new_password']));

                    $stmt->execute();

                    $__response_status_code = 200;
                    $__response_data = array(
                        'response_body' => array(
                            'message' => 'Change password success.'
                        ),
                        'success' => true
                    );
                }
            }
        }
        catch(Exception $ex)
        {
            $__response_status_code = 500;
            $__response_data = array(
                'error' => array(
                    'errorType' => 'internal_error',
                    'message' => $ex->getMessage()
                ),
                'success' => false
            );
        }

        return $res->withJson($__response_data, $__response_status_code);
    }
}
