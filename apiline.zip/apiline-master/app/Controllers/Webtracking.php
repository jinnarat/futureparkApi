<?php

namespace App;

use \Psr\Container\ContainerInterface;
use \Psr\Http\Message\ServerRequestInterface as Request;
use \Psr\Http\Message\ResponseInterface as Response;

class Webtracking extends App
{
    public function __construct(ContainerInterface $container)
    {
        parent::__construct($container);
    }

    public function tracking(Request $req, Response $res, array $args)
    {
        $db_api_tracking = $this->db_api_tracking;
        $db_cdpmkt = $this->db_cdpmkt;

        try
        {
            $db_api_tracking->beginTransaction();
            $db_cdpmkt->beginTransaction();

            $datetime_now = date('Y-m-d H:i:s');
            $query_string = $req->getQueryParams();

            $device = isset($query_string['device']) ? $query_string['device'] : NULL;
            $browser = isset($query_string['browser']) ? $query_string['browser'] : NULL;
            $element_id = isset($query_string['element_id']) ? $query_string['element_id'] : NULL;
            $element = isset($query_string['element']) ? $query_string['element'] : NULL;
            $page_title = isset($query_string['page_title']) ? urldecode($query_string['page_title']) : NULL;
            $person_id = isset($query_string['person_id']) ? urldecode($query_string['person_id']) : NULL;
            $url = isset($query_string['url']) ? urldecode($query_string['url']) : NULL;
            $latitude = isset($query_string['latitude']) ? $query_string['latitude'] : NULL;
            $longitude = isset($query_string['longitude']) ? $query_string['longitude'] : NULL;
            $session_id = isset($query_string['session_id']) ? $query_string['session_id'] : NULL;
    
            $stmt = $db_api_tracking->prepare('EXEC _Tracking @type = ?, @application_id = ?, @tracking_event = ?, @tracking_device = ?, @tracking_browser = ?, @tracking_page_title = ?, @tracking_element_id = ?, @tracking_element = ?, @tracking_url = ?, @tracking_ip_address = ?, @tracking_latitude = ?, @tracking_longitude = ?, @tracking_session_id = ?, @tracking_status = ?, @tracking_createdatetime = ?, @tracking_createby = ?, @tracking_updatedatetime = ?, @tracking_updateby = ?');
            
            $stmt->bindValue(1, 'Insert');
            $stmt->bindValue(2, $query_string['appId']);
            $stmt->bindValue(3, $query_string['event']);
            $stmt->bindValue(4, $device);
            $stmt->bindValue(5, $browser);
            $stmt->bindValue(6, $page_title);
            $stmt->bindValue(7, $element_id);
            $stmt->bindValue(8, $element);
            $stmt->bindValue(9, $url);
            $stmt->bindValue(10, $this->getIpAddress());
            $stmt->bindValue(11, $latitude);
            $stmt->bindValue(12, $longitude);
            $stmt->bindValue(13, $session_id);
            $stmt->bindValue(14, 'Active');
            $stmt->bindValue(15, $datetime_now);
            $stmt->bindValue(16, 1);
            $stmt->bindValue(17, $datetime_now);
            $stmt->bindValue(18, 1);

            $stmt->execute();

            $stmt = $db_cdpmkt->prepare('EXEC _Person_Session @type = ?, @person_id = ?, @session_id = ?, @status = ?, @createdatetime = ?, @updatedatetime = ?');

            $stmt->bindValue(1, 'Insert');
            $stmt->bindValue(2, $person_id);
            $stmt->bindValue(3, $session_id);
            $stmt->bindValue(4, 'Active');
            $stmt->bindValue(5, $datetime_now);
            $stmt->bindValue(6, $datetime_now);

            $stmt->execute();

            $db_api_tracking->commit();
            $db_cdpmkt->commit();
        }
        catch(Exception $ex)
        {
            $db_api_tracking->rollBack();
            $db_cdpmkt->rollBack();
        }
    }
}
