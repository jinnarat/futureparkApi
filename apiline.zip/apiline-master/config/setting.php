<?php

return [
    'settings' => [
        'addContentLengthHeader' => false,

        'db_api_tracking' => [
            'host' => 'DESKTOP-VERUJGT',
            'user' => 'sa',
            'pass' => '123456',            
            'dbname' => 'api_tracking',
        ],
        
        'db_cdpmkt' => [
            'host' => 'DESKTOP-VERUJGT',
            'user' => 'sa',
            'pass' => '123456',            
            'dbname' => 'cdpmkt',
        ],        

        'displayErrorDetails' => true,

        'sms' => [
            'enable' => false,
            'host' => 'http://api2.infobip.com',
            'user' => 'SundaeDemo',
            'pass' => 'Sundae_2019',
            'sender_name' => 'FuturePark'
        ],

        'otp_template' => [
            'register' => 'OTP = {{otp}} (Ref: {{reff}}) ใช้สำหรับยืนยันเบอร์โทรศัพท์ ภายใน 5 นาที',
            'verify_email' => 'OTP = {{otp}} (Ref: {{reff}}) ใช้สำหรับยืนยันอีเมล ภายใน 5 นาที',
            'forgot_password' => 'OTP = {{otp}} (Ref: {{reff}}) ใช้สำหรับยืนยัน{{chanel}} ภายใน 5 นาที'
        ],

        'smtp' => [
            'enable' => true,
            'host' => 'smtp.gmail.com',
            'user' => 'no-reply@futurepark.co.th',
            'pass' => 'Fut2017$$',
            'port' => 587,
            'sender_name' => 'Future Park'
        ],

        'path' => [
            'cdpmkt_physical_path' => 'D:/Developers/Projects/Sundae/Dev/cdpmkt/'
        ],

        'url' => [
            'cdpmkt' => 'http://localhost/cdpmkt/'
        ]
    ],
];