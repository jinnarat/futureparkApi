<?php

return [
    'settings' => [
        'addContentLengthHeader' => false,

        'db_api_tracking' => [
            'host' => '128.128.0.55',
            'user' => 'sundae',
            'pass' => 'Sundae@1899',
            'dbname' => 'api_tracking',
        ],

        'db_cdpmkt' => [
            'host' => '128.128.0.55',
            'user' => 'sundae',
            'pass' => 'Sundae@1899',
            'dbname' => 'cdpmkt',
        ],          

        'displayErrorDetails' => true,

        'sms' => [
            'enable' => false,
            'host' => 'http://api2.infobip.com',
            'user' => 'FuturePark',
            'pass' => 'RAjp3fUG',
            'sender_name' => 'FuturePark'
        ],

        'otp_template' => [
            'register' => 'รหัส OTP สำหรับยืนยันเบอร์โทรศัพท์ คือ {{otp}} (รหัสอ้างอิง {{reff}}) กรุณาใช้ภายใน 5 นาที',
            'verify_email' => 'รหัส OTP สำหรับยืนยันอีเมล คือ {{otp}} (รหัสอ้างอิง {{reff}}) กรุณาใช้ภายใน 5 นาที',
            'forgot_password' => 'รหัส OTP สำหรับยืนยัน{{chanel}} คือ {{otp}} (รหัสอ้างอิง {{reff}}) กรุณาใช้ภายใน 5 นาที'
        ],

        'smtp' => [
            'enable' => false,
            'host' => 'smtp.gmail.com',
            'user' => 'no-reply@futurepark.co.th',
            'pass' => 'Fut2017$$',
            'port' => 587,
            'sender_name' => 'Future Park'
        ],
    ],
];