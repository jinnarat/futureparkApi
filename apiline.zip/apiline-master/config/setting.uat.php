<?php

return [
    'settings' => [
        'addContentLengthHeader' => false,

        'db_api_tracking' => [
            'host' => '128.127.0.5',
            'user' => 'sundae',
            'pass' => 'Sundae@1899',            
            'dbname' => 'api_tracking',
        ],
        
        'db_cdpmkt' => [
            'host' => '128.127.0.5',
            'user' => 'sundae',
            'pass' => 'Sundae@1899',            
            'dbname' => 'cdpmkt',
        ],

        'displayErrorDetails' => true,

        'sms' => [
            'enable' => false,
            'host' => 'http://api2.infobip.com',
            'user' => 'SundaeDemo',
            'pass' => 'Sundae_2019',
            'sender_name' => 'FuturePark'
        ],

        'otp_template' => [
            'register' => 'รหัส OTP สำหรับยืนยันเบอร์โทรศัพท์ คือ {{otp}} (รหัสอ้างอิง {{reff}}) กรุณาใช้ภายใน 5 นาที',
            'verify_email' => 'รหัส OTP สำหรับยืนยันอีเมล คือ {{otp}} (รหัสอ้างอิง {{reff}}) กรุณาใช้ภายใน 5 นาที',
            'forgot_password' => 'รหัส OTP สำหรับยืนยัน{{chanel}} คือ {{otp}} (รหัสอ้างอิง {{reff}}) กรุณาใช้ภายใน 5 นาที'
        ],

        'smtp' => [
            'enable' => false,
            'host' => 'mail.sundae.co.th',
            'user' => 'jinnarat.r@sundae.co.th',
            'pass' => '$undae@2o19;',
            'port' => 25,
            'sender_name' => 'Future Park'
        ],
    ],
];