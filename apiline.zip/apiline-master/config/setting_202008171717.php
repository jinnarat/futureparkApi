<?php

return [
    'settings' => [
        'addContentLengthHeader' => false,

        'db_api_tracking' => [
            'host' => '128.127.0.5',
            'user' => 'sundae',
            'pass' => 'Sundae@1899',            
            'dbname' => 'api_tracking',
        ],

        'db_cdpmkt' => [
            'host' => '128.127.0.5',
            'user' => 'sundae',
            'pass' => 'Sundae@1899',            
            'dbname' => 'cdpmkt',
        ],        

        'displayErrorDetails' => true,

        'sms' => [
            'enable' => true,
            'host' => 'http://api2.infobip.com',
            'user' => 'FuturePark',
            'pass' => 'RAjp3fUG',
            'sender_name' => 'FuturePark'
        ],

       'otp_template' => [
    'register' => 'OTP : {{otp}} (REF: {{reff}})',
    'verify_email' => 'OTP : {{otp}} (REF: {{reff}})',
    'forgot_password' => 'OTP : {{otp}} (REF: {{reff}})'
],

        'smtp' => [
            'enable' => true,
            'host' => 'smtp.gmail.com',
            'user' => 'no-reply@futurepark.co.th',
            'pass' => 'Fut2017$$',
            'port' => 587,
            'sender_name' => 'Future Park'
        ],
    ],
];