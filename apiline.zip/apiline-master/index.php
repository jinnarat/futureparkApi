<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

use \Psr\Http\Message\ServerRequestInterface as Request;
use \Psr\Http\Message\ResponseInterface as Response;

require 'vendor/autoload.php';

$config = include('config/setting.php');

$app = new \Slim\App($config);

$container = $app->getContainer();

$container['db_api_tracking'] = function ($c) {
    $settings = $c->get('settings')['db_api_tracking'];
    
    $pdo = new PDO("sqlsrv:server=" . $settings['host'] . ";database=" . $settings['dbname'], $settings['user'], $settings['pass']);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
    $pdo->setAttribute(PDO::SQLSRV_ATTR_ENCODING, PDO::SQLSRV_ENCODING_UTF8);

    return $pdo;
};

$container['db_cdpmkt'] = function ($c) {
    $settings = $c->get('settings')['db_cdpmkt'];
    
    $pdo = new PDO("sqlsrv:server=" . $settings['host'] . ";database=" . $settings['dbname'], $settings['user'], $settings['pass']);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
    $pdo->setAttribute(PDO::SQLSRV_ATTR_ENCODING, PDO::SQLSRV_ENCODING_UTF8);

    return $pdo;
};

$container['otp_template'] = function ($c) {
    return $c->get('settings')['otp_template'];
};

$container['sms'] = function ($c) {
    return $c->get('settings')['sms'];
};

$container['smtp'] = function ($c) {
    return $c->get('settings')['smtp'];
};

$container['path'] = function ($c) {
    return $c->get('settings')['path'];
};

$container['url'] = function ($c) {
    return $c->get('settings')['url'];
};

$container['App\Member'] = function ($container) {
    return new App\Member($container);
};

$container['App\Oauth'] = function ($container) {
    return new App\Oauth($container);
};

$container['App\Webtracking'] = function ($container) {
    return new App\Webtracking($container);
};

// $container['errorHandler'] = function($container) {
//     return function ($request, $response, \Exception $exception) use ($container) {

//         $__response_status_code = 500;
//         $__response_data = array(
//             'error' => array(
//                 'errorType' => 'internal error',
//                 'message' => $exception->getMessage(),
//             ),
//             'success' => false
//         );

//         return $response->withJson($__response_data, $__response_status_code);   
//     };
// };

// $container['phpErrorHandler'] = function($container) {
//     return $container['errorHandler'];
// };

// $container['notFoundHandler'] = function($container) {
//     return function ($request, $response) use ($container) {

//         $__response_status_code = 404;
//         $__response_data = array(
//             'error' => array(
//                 'errorType' => 'not found',
//                 'message' => 'Endpoint was not found. Check API documentation for valid endpoints.'
//             ),
//             'success' => false
//         );

//         return $response->withJson($__response_data, $__response_status_code);
//     };
// };

// $container['notAllowedHandler'] = function($container) {
//     return function ($request, $response, $methods) use ($container) {
//         $__response_status_code = 405;
//         $__response_data = array(
//             'error' => array(
//                 'errorType' => 'method not allow',
//                 'message' => 'HTTP request method is not allowed. Method must be of: ' . implode(', ', $methods),
//             ),
//             'success' => false
//         );

//         return $response->withJson($__response_data, $__response_status_code);
//     };
// };

$app->post('/person/change_password', 'App\Person:change_password');
$app->post('/person/check_line_id', 'App\Person:check_line_id');
$app->post('/person/check_status', 'App\Person:check_status');
$app->post('/person/profile', 'App\Person:profile');
$app->post('/person/register', 'App\Person:register');
$app->post('/person/verify', 'App\Person:verify');
$app->post('/person/update_address', 'App\Person:update_address');
$app->post('/person/update_data', 'App\Person:update_data');
$app->post('/oauth2/token', 'App\Oauth2:token');
$app->post('/otp/send', 'App\Otp:send');
$app->post('/otp/verify', 'App\Otp:verify');

$app->get('/webtracking/tracking', 'App\Webtracking:tracking');

$app->run();